#include <stdio.h>
#include <string.h>

#include "mag_level2_data_4min.h"
#include "df.h"
#include "mfhdf.h"

int main(argc, argv)
int argc;
char *argv[];
{
  int32 hdf_fp, sd_id;
  struct MAG_data_4min *testdata;
  int ii,jj,retval;
  int32 numrec;

  if (argc!=2)
    {
      printf("Usage: mag_l2_4min_rd hdf_file\n");
      exit(1);
    }

  testdata=malloc(sizeof(struct MAG_data_4min));

  /* open hdf input file */

  if ((hdf_fp=Hopen(argv[1], DFACC_RDONLY, 0))==FAIL) {
      fprintf(stderr, "Hopen: could not open hdf file\n");
      exit(-1);
    }
  Vstart(hdf_fp);

  if ((sd_id=SDstart(argv[1], DFACC_RDONLY))==FAIL) {
	  fprintf(stderr, "SDstart: could not open hdf file\n");
	  exit(-1);
	}

  numrec=init_rd_mag_level2_data_4min(hdf_fp, sd_id, "r");

  if( numrec<=0) {
    fprintf(stderr,"No mag level2 4min data\n");
    exit(-1);
  }

  ii=0;
  while((retval= read_mag_level2_data_4min(testdata,ii))!=-1) {
	  printf("%4d %11.6f %3d %2d %2d %5.2f ",
		 testdata->year,testdata->fp_year,testdata->day,testdata->hr,testdata->min,testdata->sec);
	  printf("%10.4f %10.4f %10.4f %10.4f %10.4f %10.4f ", 
		 testdata->Bgse_x, testdata->Bgse_y, testdata->Bgse_z,
		 testdata->Bmag, testdata->Delta, testdata->Lambda);		 
	  printf("%10.4f %10.4f %5.2f %4d\n", 
		 testdata->dBrms, testdata->sigma_B, testdata->fraction_good,testdata->N_vectors);
	  ii++;
  }

  /* all done, close HDF file */

  close_rd_mag_level2_data_4min();
  Vend(hdf_fp);
  if (SDend(sd_id)==FAIL) {
      fprintf(stderr, "SDend: could not close hdf file\n");
      exit(-1);
    }
  if (Hclose(hdf_fp)==FAIL) {
      fprintf(stderr, "Hclose: could not close hdf file\n");
      exit(-1);
    }

  exit(0);
}


