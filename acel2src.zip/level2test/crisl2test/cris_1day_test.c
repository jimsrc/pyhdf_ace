#include <stdio.h>
#include <string.h>
#include <time.h>
#include <stddef.h>

#include "cris_level2_data_1day.h"
#include "cris_sizes.h"
#include "df.h"
#include "mfhdf.h"

int main(argc, argv)
int argc;
char *argv[];
{
  int32 hdf_fp, sd_id;
  struct CRIS_data_1day *testdata;
  
  printf("%d\n",offsetof(struct CRIS_data_1day, flux_B[7]));
  printf("%d\n",offsetof(struct CRIS_data_1day, flux_C));

  exit(0);
}


