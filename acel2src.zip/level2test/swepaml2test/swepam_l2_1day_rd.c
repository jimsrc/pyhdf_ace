#include <stdio.h>
#include <string.h>

#include "swepam_level2_data_1day.h"
#include "df.h"
#include "mfhdf.h"

int main(argc, argv)
int argc;
char *argv[];
{
  int32 hdf_fp, sd_id;
  struct SWEPAM_data_1day *testdata;
  int ii,jj,retval;
  int32 numrec;

  if (argc!=2)
    {
      printf("Usage: swepam_l2_1day_rd hdf_file\n");
      exit(1);
    }

  testdata=malloc(sizeof(struct SWEPAM_data_1day));

  /* open hdf input file */

  if ((hdf_fp=Hopen(argv[1], DFACC_RDONLY, 0))==FAIL) {
      fprintf(stderr, "Hopen: could not open hdf file\n");
      exit(-1);
    }
  Vstart(hdf_fp);

  if ((sd_id=SDstart(argv[1], DFACC_RDONLY))==FAIL) {
	  fprintf(stderr, "SDstart: could not open hdf file\n");
	  exit(-1);
	}

  numrec=init_rd_swepam_level2_data_1day(hdf_fp, sd_id, "r");

  if( numrec<=0) {
    fprintf(stderr,"No swepam level2 1day data\n");
    exit(-1);
  }

  ii=0;
  while((retval= read_swepam_level2_data_1day(testdata,ii))!=-1) {
	  printf("%4d %11.6f %3d %2d %2d %5.2f ",
		 testdata->year,testdata->fp_year,testdata->day,testdata->hr,testdata->min,testdata->sec);
          printf("%10.3f %10.2f %10.3f %10.3f %10.3f %10.3f %10.3f  %10.3f %10.3f %10.3f\n",
                 testdata->proton_density, testdata->proton_temp, testdata->He4toprotons,
                 testdata->proton_speed,
		 testdata->x_dot_GSE, testdata->y_dot_GSE, testdata->z_dot_GSE,
		 testdata->x_dot_GSM, testdata->y_dot_GSM, testdata->z_dot_GSM);
	  ii++;
  }

  /* all done, close HDF file */

  close_rd_swepam_level2_data_1day();
  Vend(hdf_fp);
  if (SDend(sd_id)==FAIL) {
      fprintf(stderr, "SDend: could not close hdf file\n");
      exit(-1);
    }
  if (Hclose(hdf_fp)==FAIL) {
      fprintf(stderr, "Hclose: could not close hdf file\n");
      exit(-1);
    }

  exit(0);
}


