/* $Id: sis_level2_factors_energy_levels.h,v 1.1 2000/08/02 00:52:03 asc Exp asc $ */

#include "hdfi.h"
#include "sis_sizes.h"

struct SIS_factors_energy_levels {

  float32 factors[NUMBER_OF_ENERGY_BANDS];
  float32 range_lower[NUMBER_OF_ENERGY_BANDS];
  float32 range_upper[NUMBER_OF_ENERGY_BANDS];

};




