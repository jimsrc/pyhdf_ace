/* $Id: sis_sizes.h,v 1.1 2000/08/02 00:52:26 asc Exp asc $ */

/* Sizes for arrays are: */
#define NUMBER_OF_ELEMENTS 14
#define NUMBER_OF_ENERGY_BANDS 8


