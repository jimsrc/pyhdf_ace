/* $Id: cris_sizes.h,v 1.1 2000/08/01 23:50:10 asc Exp $ */

/* Sizes for arrays are: */
#define NUMBER_OF_ELEMENTS_ABUNDANT  8
#define NUMBER_OF_ELEMENTS_RARE      16
#define NUMBER_OF_ELEMENTS_TOTAL     28

#define NUMBER_OF_ENERGY_LEVELS      7

#define NUMBER_OF_POINTS_ABUNDANT    9116
#define NUMBER_OF_POINTS_RARE        2279
























