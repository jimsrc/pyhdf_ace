/* $Id: sepica_level2_energy_levels.h,v 1.1 2000/08/02 00:50:14 asc Exp $ */

#include "hdfi.h"

struct SEPICA_energy_levels {

  float32 energy_lower;
  float32 energy_upper;

};
