/* $Id:$ */

#include "hdfi.h"

struct SS_data_1hr {

  /* UT time at the start of each record */
  int32   year;                         /* integer year */
  int32   day;                          /* integer day of year */
  int32   hr;                           /* hour of day */
  int32   min;                          /* min of hour */
  float32 sec;                          /* seconds of minute */
  float64 fp_year;                      /* floating point year */
  float64 fp_doy;                       /* floating point Day of Year */ 
  float64 ACEepoch;                     /* UT time in sec since 1/1/96 */

  float32 nHe2;

  float32 vHe2;
  float32 vC5;
  float32 vO6;
  float32 vFe10;

  float32 vthHe2;
  float32 vthC5;
  float32 vthO6;
  float32 vthFe10;

  int16 He_qual;    /* quality flags - see release notes */
  int16 C5_qual;
  int16 O6_qual;
  int16 Fe10_qual;

  float32 C6to5;
  float32 O7to6;
  float32 avqC;
  float32 avqO;
  float32 avqFe;


  int16 C6to5_qual;
  int16 O7to6_qual;
  int16 avqC_qual;
  int16 avqO_qual;
  int16 avqFe_qual;

  int16 SW_type;    /* solar wind type indicator */

  float32 FetoO;
  int16 FetoO_qual;
   
};












