/* $Id: epam_level2_data_Bartels.h,v 1.1 2000/08/02 00:45:42 asc Exp $ */

#include "hdfi.h"

struct EPAM_data_Bartels {

  /* UT time at the start of the periods */
  int32   year;                         /* integer year */
  int32   day;                          /* integer day of year */
  int32   hr;                           /* hour of day */
  int32   min;                          /* min of hour */
  float32 sec;                          /* seconds */
  float64 fp_year;                      /* floating point year */
  float64 fp_doy;                       /* floating point Day of YearDOY */ 
  float64 ACEepoch;                     /* UT time in sec since 1/1/96 */

  float32 P1; 
  float32 P2; 
  float32 P3; 
  float32 P4; 
  float32 P5; 
  float32 P6; 
  float32 P7; 
  float32 P8; 

  float32 unc_P1; 
  float32 unc_P2; 
  float32 unc_P3; 
  float32 unc_P4; 
  float32 unc_P5; 
  float32 unc_P6; 
  float32 unc_P7; 
  float32 unc_P8; 

  float32 DE1; 
  float32 DE2; 
  float32 DE3; 
  float32 DE4; 

  float32 unc_DE1; 
  float32 unc_DE2; 
  float32 unc_DE3; 
  float32 unc_DE4; 

  float32 W3; 
  float32 W4; 
  float32 W5; 
  float32 W6;
  float32 W7; 
  float32 W8;

  float32 unc_W3; 
  float32 unc_W4; 
  float32 unc_W5; 
  float32 unc_W6; 
  float32 unc_W7; 
  float32 unc_W8;

  float32 E1p;
  float32 E2p; 
  float32 E3p; 
  float32 E4p; 
  float32 FP5p; 
  float32 FP6p; 
  float32 FP7p; 

  float32 unc_E1p;
  float32 unc_E2p; 
  float32 unc_E3p; 
  float32 unc_E4p; 
  float32 unc_FP5p; 
  float32 unc_FP6p; 
  float32 unc_FP7p; 

  float32 Z2; 
  float32 Z2A; 
  float32 Z3; 
  float32 Z4; 

  float32 unc_Z2; 
  float32 unc_Z2A; 
  float32 unc_Z3; 
  float32 unc_Z4; 

  float32 P1p; 
  float32 P2p; 
  float32 P3p; 
  float32 P4p; 
  float32 P5p; 
  float32 P6p; 
  float32 P7p; 
  float32 P8p; 

  float32 unc_P1p; 
  float32 unc_P2p; 
  float32 unc_P3p; 
  float32 unc_P4p; 
  float32 unc_P5p; 
  float32 unc_P6p; 
  float32 unc_P7p; 
  float32 unc_P8p; 
 
  float32 E1;
  float32 E2; 
  float32 E3; 
  float32 E4; 
  float32 FP5; 
  float32 FP6; 
  float32 FP7; 

  float32 unc_E1;
  float32 unc_E2; 
  float32 unc_E3; 
  float32 unc_E4; 
  float32 unc_FP5; 
  float32 unc_FP6; 
  float32 unc_FP7; 

  float32 livetime;

};

