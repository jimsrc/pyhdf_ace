/* $Id: $ */

/* sweswi_level2_V3data_1day.h */

#include "hdfi.h"

struct SS_data_1day {

  /* UT time at the start of each period */
  int32   year;                         /* integer year */
  int32   day;                          /* integer day of year */
  int32   hr;                           /* hour of day */
  int32   min;                          /* min of hour */
  float32 sec;                          /* seconds */
  float64 fp_year;                      /* floating point year */
  float64 fp_doy;                       /* floating point Day of YearDOY */ 
  float64 ACEepoch;                     /* UT time in sec since 1/1/96 */

  float32 vHe2;

  float32 C6to5;
  float32 O7to6;
  float32 aveqC;
  float32 aveqO;
  float32 aveqFe;

  int16 C6to5_qual;
  int16 O7to6_qual;
  int16 aveqC_qual;
  int16 aveqO_qual;
  int16 aveqFe_qual;

  float32 He3to4;
  int16 He3to4_qual;
  float32 HetoO;
  int16 HetoO_qual;
  float32 CtoO;
  int16 CtoO_qual;
  float32 NtoO;
  int16 NtoO_qual;
  float32 NetoO;
  int16 NetoO_qual;
  float32 MgtoO;
  int16 MgtoO_qual;
  float32 SitoO;
  int16 SitoO_qual;
  float32 StoO;
  int16 StoO_qual;
  float32 FetoO;
  int16 FetoO_qual;

  int16   SW_type;

};
