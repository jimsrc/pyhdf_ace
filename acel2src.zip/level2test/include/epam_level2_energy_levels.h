/* $Id: epam_level2_energy_levels.h,v 1.1 2000/08/02 00:45:52 asc Exp $ */

#include "hdfi.h"

#define NUMBER_OF_MEASURMENTS  44

struct EPAM_energy_levels {

  float32 energy_lower;
  float32 energy_upper;
  float32 geometric_factor;

};
