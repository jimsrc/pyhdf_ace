/* $Id: uleis_level2_data_Bartels.h,v 1.2 2008/09/11 00:00:10 asc Exp $ */

#include "hdfi.h"

struct ULEIS_data_Bartels {

  /* UT time at the start of the periods */
  int32   year;                         /* integer year */
  int32   day;                          /* integer day of year */
  int32   hr;                           /* hour of day */
  int32   min;                          /* min of hour */
  float32 sec;                          /* seconds */
  float64 fp_year;                      /* floating point year */
  float64 fp_doy;                       /* floating point Day of YearDOY */ 
  float64 ACEepoch;                     /* UT time in sec since 1/1/96 */

  float32 H_S1; 
  float32 H_S2; 
  float32 H_S3; 
  float32 H_S4;
  float32 H_S5;

  float32 unc_H_S1; 
  float32 unc_H_S2; 
  float32 unc_H_S3; 
  float32 unc_H_S4;
  float32 unc_H_S5;

  float32 He3_S1; 
  float32 He3_S2; 
  float32 He3_L2;
  float32 He3_L3;
  float32 He3_L4;
  float32 He3_L5;
  float32 He3_L6;

  float32 unc_He3_S1; 
  float32 unc_He3_S2; 
  float32 unc_He3_L2;
  float32 unc_He3_L3;
  float32 unc_He3_L4;
  float32 unc_He3_L5;
  float32 unc_He3_L6;

  float32 He4_S1;
  float32 He4_S2;
  float32 He4_S3;
  float32 He4_L1;
  float32 He4_L2;
  float32 He4_L3;
  float32 He4_L4;
  float32 He4_L5;
  float32 He4_L6;
  float32 He4_L7;
  float32 He4_L8;
  float32 He4_L9;
  float32 He4_L10;
  float32 He4_L11;
  float32 He4_L12;

  float32 unc_He4_S1;
  float32 unc_He4_S2;
  float32 unc_He4_S3;
  float32 unc_He4_L1;
  float32 unc_He4_L2;
  float32 unc_He4_L3;
  float32 unc_He4_L4;
  float32 unc_He4_L5;
  float32 unc_He4_L6;
  float32 unc_He4_L7;
  float32 unc_He4_L8;
  float32 unc_He4_L9;
  float32 unc_He4_L10;
  float32 unc_He4_L11;
  float32 unc_He4_L12;

  float32 C_S1;
  float32 C_L1;
  float32 C_L2;
  float32 C_L3;
  float32 C_L4;
  float32 C_L5;
  float32 C_L6;
  float32 C_L7;
  float32 C_L8;

  float32 unc_C_S1;
  float32 unc_C_L1;
  float32 unc_C_L2;
  float32 unc_C_L3;
  float32 unc_C_L4;
  float32 unc_C_L5;
  float32 unc_C_L6;
  float32 unc_C_L7;
  float32 unc_C_L8;

  float32 O_S1;
  float32 O_L1;
  float32 O_L2;
  float32 O_L3;
  float32 O_L4;
  float32 O_L5;
  float32 O_L6;
  float32 O_L7;

  float32 unc_O_S1;
  float32 unc_O_L1;
  float32 unc_O_L2;
  float32 unc_O_L3;
  float32 unc_O_L4;
  float32 unc_O_L5;
  float32 unc_O_L6;
  float32 unc_O_L7;

  float32 Ne_S_L1;
  float32 Ne_S_L2;
  float32 Ne_S_L3;
  float32 Ne_S_L4;
  float32 Ne_S_L5;
  float32 Ne_S_L6;
  float32 Ne_S_L7;

  float32 unc_Ne_S_L1;
  float32 unc_Ne_S_L2;
  float32 unc_Ne_S_L3;
  float32 unc_Ne_S_L4;
  float32 unc_Ne_S_L5;
  float32 unc_Ne_S_L6;
  float32 unc_Ne_S_L7;

  float32 Fe_L1;
  float32 Fe_L2;
  float32 Fe_L3;
  float32 Fe_L4;
  float32 Fe_L5;
  float32 Fe_L6;
  float32 Fe_L7;
  float32 Fe_L8;
  float32 Fe_L9;

  float32 unc_Fe_L1;
  float32 unc_Fe_L2;
  float32 unc_Fe_L3;
  float32 unc_Fe_L4;
  float32 unc_Fe_L5;
  float32 unc_Fe_L6;
  float32 unc_Fe_L7;
  float32 unc_Fe_L8;
  float32 unc_Fe_L9;

};
