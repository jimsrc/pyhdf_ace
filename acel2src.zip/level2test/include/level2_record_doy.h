/* $Id: level2_record_doy.h,v 1.1 2000/08/02 00:47:11 asc Exp $ */

#include "hdfi.h"

/* record year/DOY association */
struct level2_record_doy {

  int32   record_number;             /* record number */
  int32   year;                      /* integer year */
  int32   day;                       /* integer day of year */
  int32   days_jan_1_1996;           /* days since January 1, 1996 UT 0 hr*/

};
