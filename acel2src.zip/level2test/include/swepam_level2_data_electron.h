/* $Id: swepam_level2_data_electron.h,v 1.1 2000/08/02 00:53:37 asc Exp $ */

/* swepam_level2_data_electron.h */

#include "hdfi.h"

struct SWEPAM_electron {

  /* UT time at the start of the periods */
  int32   year;                         /* integer year */
  int32   day;                          /* integer day of year */
  int32   hr;                           /* hour of day */
  int32   min;                          /* min of hour */
  float32 sec;                          /* seconds */
  float64 fp_year;                      /* floating point year */
  float64 fp_doy;                       /* floating point Day of YearDOY */ 
  float64 ACEepoch;                     /* UT time in sec since 1/1/96 */

  /* SWEPAM data */
  float32 Electron_temp;
};
