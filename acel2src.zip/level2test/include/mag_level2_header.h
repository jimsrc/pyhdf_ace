/* $Id: mag_level2_header.h,v 1.1 2000/08/02 00:48:38 asc Exp $ */

#include "hdfi.h"

#define Number_Maneuver 3

struct MAG_header {

  uint32 Nser;
  uint32 Npts;
  uint32 Nheader;
  uint8 Data_Type[10];
  uint8 Coords[3];
  float32 Delta_t_sec; 
  uint8 Filename[80];
  uint8 Level_1_source_file[80];

  uint32 Maneuver_count;
  float64 Maneuver_start[Number_Maneuver];
  float64 Maneuver_end[Number_Maneuver];
  uint32 c1[Number_Maneuver];
  uint32 c2[Number_Maneuver];

  float32 begin_location_gse_x;
  float32 begin_location_gse_y;
  float32 begin_location_gse_z;

  float32 end_location_gse_x;
  float32 end_location_gse_y;
  float32 end_location_gse_z;

  float32 begin_location_gsm_x;
  float32 begin_location_gsm_y;
  float32 begin_location_gsm_z;

  float32 end_location_gsm_x;
  float32 end_location_gsm_y;
  float32 end_location_gsm_z;

  float32 begin_location_gci_x;
  float32 begin_location_gci_y;
  float32 begin_location_gci_z;

  float32 end_location_gci_x;
  float32 end_location_gci_y;
  float32 end_location_gci_z;

  float32 begin_attitude_cosines_rtn_r;
  float32 begin_attitude_cosines_rtn_t;
  float32 begin_attitude_cosines_rtn_n;

  float32 end_attitude_cosines_rtn_r;
  float32 end_attitude_cosines_rtn_t;
  float32 end_attitude_cosines_rtn_n;

  float32 begin_attitude_cosines_gse_x;
  float32 begin_attitude_cosines_gse_y;
  float32 begin_attitude_cosines_gse_z;

  float32 end_attitude_cosines_gse_x;
  float32 end_attitude_cosines_gse_y;
  float32 end_attitude_cosines_gse_z;

  float32 begin_attitude_cosines_gsm_x;
  float32 begin_attitude_cosines_gsm_y;
  float32 begin_attitude_cosines_gsm_z;

  float32 end_attitude_cosines_gsm_x;
  float32 end_attitude_cosines_gsm_y;
  float32 end_attitude_cosines_gsm_z;

};


















