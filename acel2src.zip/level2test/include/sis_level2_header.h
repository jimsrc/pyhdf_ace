/* $Id: sis_level2_header.h,v 1.1 2000/08/02 00:52:17 asc Exp asc $ */

#include "hdfi.h"
#include "sis_sizes.h"

struct SIS_header {

  char8    filename[80];
  char8    time_date_made[80];
  float32  software_version;
  int16    start_time[6];
  int16    stop_time[6];

  int16    Bartels_rotation;
  char8    ACE_Instrument[80];
  char8    ACE_SIS_Contact[80];

  float32  Z_Range_start;
  float32  Z_Range_stop;

  int32    Z_file;

  float32  Z10_cut_lower[NUMBER_OF_ENERGY_BANDS];
  float32  Z10_cut_upper[NUMBER_OF_ENERGY_BANDS];

  float32  Z20_cut_lower[NUMBER_OF_ENERGY_BANDS];
  float32  Z20_cut_upper[NUMBER_OF_ENERGY_BANDS];

};













