/* $Id: uleis_level2_header.h,v 1.1 2000/08/02 00:56:09 asc Exp $ */

#include "hdfi.h"

#define  NUMBER_OF_DATA_FILES 7

struct ULEIS_header {

  int32 Num;

  uint8 UDES[100];
  uint8 ASC_HDF[100];
  uint8 CAL[100];
  uint8 FILTER[100];
  uint8 AVG_INTERVAL[100];
  uint8 Created[100];

  uint8 header_1_a[200];
  uint8 header_1_b[200];
  uint8 header_1_c[200];

  uint8 header_2_a[200];
  uint8 header_2_b[200];
  uint8 header_2_c[200];

  uint8 header_3_a[200];
  uint8 header_3_b[200];
  uint8 header_3_c[200];

  uint8 header_4_a[200];
  uint8 header_4_b[200];
  uint8 header_4_c[200];

  uint8 header_5_a[200];
  uint8 header_5_b[200];
  uint8 header_5_c[200];

  uint8 header_6_a[200];
  uint8 header_6_b[200];
  uint8 header_6_c[200];

  uint8 header_7_a[200];
  uint8 header_7_b[200];
  uint8 header_7_c[200];

};








































