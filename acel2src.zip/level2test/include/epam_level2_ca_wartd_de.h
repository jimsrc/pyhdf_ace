/* $Id: epam_level2_ca_wartd_de.h,v 1.1 2000/08/02 00:40:18 asc Exp $ */

#include "hdfi.h"

struct EPAM_data_ca_wartd_de {

  /* UT time at the start of the periods */
  int32   year;                         /* integer year */
  int32   day;                          /* integer day of year */
  int32   hr;                           /* hour of day */
  int32   min;                          /* min of hour */
  float32 sec;                          /* seconds */
  float64 fp_year;                      /* floating point year */
  float64 fp_doy;                       /* floating point Day of YearDOY */ 
  float64 ACEepoch;                     /* UT time in sec since 1/1/96 */

  float32 W3; 
  float32 W4; 
  float32 W5; 
  float32 W6; 
  float32 W7; 
  float32 W8;

  float32 Z2; 
  float32 Z2A; 
  float32 Z3; 
  float32 Z4; 

  float32 DE1; 
  float32 DE2; 
  float32 DE3; 
  float32 DE4; 

  float32 unc_W3; 
  float32 unc_W4; 
  float32 unc_W5; 
  float32 unc_W6; 
  float32 unc_W7; 
  float32 unc_W8;

  float32 unc_Z2; 
  float32 unc_Z2A; 
  float32 unc_Z3; 
  float32 unc_Z4; 

  float32 unc_DE1; 
  float32 unc_DE2; 
  float32 unc_DE3; 
  float32 unc_DE4; 

  int32   Data_Quality;                 /* 0=good,1=fill data */ 

};

