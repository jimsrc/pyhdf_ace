/* $Id: mag_level2_data_4min.h,v 1.1 2000/08/02 00:48:18 asc Exp $ */

#include "hdfi.h"

struct MAG_data_4min {

  /* UT time at the start of the periods */
  int32   year;                         /* integer year */
  int32   day;                          /* integer day of year */
  int32   hr;                           /* hour of day */
  int32   min;                          /* min of hour */
  float32 sec;                          /* seconds */
  float64 fp_year;                      /* floating point year */
  float64 fp_doy;                       /* floating point Day of YearDOY */ 
  float64 ACEepoch;                     /* UT time in sec since 1/1/96 */

  /* ACE frame count */
  uint32 SCclock;
      
  /* mag average data */
  float32 Br;
  float32 Bt;
  float32 Bn;

  float32 Bmag;
  float32 Delta;
  float32 Lambda;

  float32 Bgse_x;
  float32 Bgse_y;
  float32 Bgse_z;

  float32 Bgsm_x;
  float32 Bgsm_y;
  float32 Bgsm_z;

  float32 dBrms;

  float32 sigma_B;

  float32 fraction_good;  
  int32   N_vectors;

  /* data quality for period; data types 1 and 2 have been excised */
  int32  Quality;                      /* =0 Normal; */
                                       /* =1 Maneuver & Relaxation*/
				       /* =2 Bad data */

  /* Sensor Position in gse coordinates */
  float32 pos_gse_x;
  float32 pos_gse_y;
  float32 pos_gse_z;

  /* Sensor Position in gsm coordinates */
  float32 pos_gsm_x;
  float32 pos_gsm_y;
  float32 pos_gsm_z;

};
