/* $Id: cris_level2_factors_energy_levels.h,v 1.1 2000/08/01 23:49:14 asc Exp $ */

#include "hdfi.h"
#include "cris_sizes.h"

struct CRIS_factors_energy_levels {

  uint8   z_number;
  float32 energy_min[NUMBER_OF_ENERGY_LEVELS];
  float32 energy_max[NUMBER_OF_ENERGY_LEVELS];
  float32 geo_factor[NUMBER_OF_ENERGY_LEVELS];
  float32 spallation[NUMBER_OF_ENERGY_LEVELS];
  float32 SOFT[NUMBER_OF_ENERGY_LEVELS];

};
