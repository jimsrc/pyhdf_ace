/* $Id: epam_level2_lefs60_lems120.h,v 1.1 2000/08/02 00:46:49 asc Exp $ */

#include "hdfi.h"

struct EPAM_data_lefs60_lems120 {

  /* UT time at the start of the periods */
  int32   year;                         /* integer year */
  int32   day;                          /* integer day of year */
  int32   hr;                           /* hour of day */
  int32   min;                          /* min of hour */
  float32 sec;                          /* seconds */
  float64 fp_year;                      /* floating point year */
  float64 fp_doy;                       /* floating point Day of YearDOY */ 
  float64 ACEepoch;                     /* UT time in sec since 1/1/96 */

  float32 E1p;
  float32 E2p; 
  float32 E3p; 
  float32 E4p; 

  float32 FP5p; 
  float32 FP6p; 
  float32 FP7p; 

  float32 P1p; 
  float32 P2p; 
  float32 P3p; 
  float32 P4p; 
  float32 P5p; 
  float32 P6p; 
  float32 P7p; 
  float32 P8p; 

  float32 unc_E1p;
  float32 unc_E2p; 
  float32 unc_E3p; 
  float32 unc_E4p; 

  float32 unc_FP5p; 
  float32 unc_FP6p; 
  float32 unc_FP7p; 

  float32 unc_P1p; 
  float32 unc_P2p; 
  float32 unc_P3p; 
  float32 unc_P4p; 
  float32 unc_P5p; 
  float32 unc_P6p; 
  float32 unc_P7p; 
  float32 unc_P8p; 

  int32   Data_Quality;                 /* 0=good,1=fill data */ 

};
