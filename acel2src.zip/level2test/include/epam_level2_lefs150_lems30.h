/* $Id: epam_level2_lefs150_lems30.h,v 1.1 2000/08/02 00:46:21 asc Exp $ */

#include "hdfi.h"

struct EPAM_data_lefs150_lems30 {

  /* UT time at the start of the periods */
  int32   year;                         /* integer year */
  int32   day;                          /* integer day of year */
  int32   hr;                           /* hour of day */
  int32   min;                          /* min of hour */
  float32 sec;                          /* seconds */
  float64 fp_year;                      /* floating point year */
  float64 fp_doy;                       /* floating point Day of YearDOY */ 
  float64 ACEepoch;                     /* UT time in sec since 1/1/96 */

  float32 E1;
  float32 E2; 
  float32 E3; 
  float32 E4; 

  float32 FP5; 
  float32 FP6; 
  float32 FP7; 

  float32 P1; 
  float32 P2; 
  float32 P3; 
  float32 P4; 
  float32 P5; 
  float32 P6; 
  float32 P7; 
  float32 P8; 

  float32 unc_E1;
  float32 unc_E2; 
  float32 unc_E3; 
  float32 unc_E4; 

  float32 unc_FP5; 
  float32 unc_FP6; 
  float32 unc_FP7; 

  float32 unc_P1; 
  float32 unc_P2; 
  float32 unc_P3; 
  float32 unc_P4; 
  float32 unc_P5; 
  float32 unc_P6; 
  float32 unc_P7; 
  float32 unc_P8; 

  int32   Data_Quality;                 /* 0=good,1=fill data */ 

};
