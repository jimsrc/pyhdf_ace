/* SWICS - lowest charge-state and number of charge-states
 * for each charge-state distribution */

#define lqC 4
#define lqO 5
#define lqNe 6 
#define lqMg 6
#define lqSi 6
#define lqFe 6

#define nqC 3
#define nqO 4
#define nqNe 4 
#define nqMg 7
#define nqSi 7
#define nqFe 15


   
