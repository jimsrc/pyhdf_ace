/* The RCS version of hdfgen.pl used to create this file is: */
/* $Id: hdfgen.pl,v 1.49 1999/11/04 17:17:13 asc Exp  */

  /* An RCS (Revision Control System) header */

  /* for the include file is not on the first line. */

#include "ss_level2_data_2hr.h"
#include "df.h"

int32 vgrp_id_ss_level2_data_2hr;
static int32 vdata_id_ss_level2_data_2hr;

  /* 1582 is the size of ss_level2_data_2hr.h + 1 added line */
char Vgrp_descrp_SS_data_2hr[1582];

/****----  init create function  ----****/

int32 init_cr_ss_level2_data_2hr(int32 hdf_fp, int32 sd_id, int32 an_id, char *classname)
{
  int32 retval=0;
  int32 vgrp_ref_w;
  int32 ann_id_w;
  int32 wr_Vgrp_desc_ss_level2_data_2hr();

  void print_ss_level2_data_2hr_error();

  /*         Setup a Vgroup         */
  if ((vgrp_id_ss_level2_data_2hr = Vattach(hdf_fp, -1, "w"))==FAIL) {
    print_ss_level2_data_2hr_error("init_cr_ss_level2_data_2hr -> Vattach: Couldn't create Vgroup");
    retval = -1;
  }
  Vsetname(vgrp_id_ss_level2_data_2hr, "VG_SS_data_2hr"); 
  Vsetclass(vgrp_id_ss_level2_data_2hr, "VG_SS_LEVEL2_DATA_2HR");


  /*      Get the Vgroup reference     */
  if ((vgrp_ref_w = Vfind(hdf_fp, "VG_SS_data_2hr" )) ==FAIL) {
    print_ss_level2_data_2hr_error("init_cr_ss_level2_data_2hr -> Vfind: Couldn't get Vgrp reference");
    retval = -1;
  }
  /*      Add a description to the Vgroup      */
  wr_Vgrp_desc_ss_level2_data_2hr(Vgrp_descrp_SS_data_2hr);

  if ((ann_id_w = ANcreate(an_id, DFTAG_VG, vgrp_ref_w, AN_DATA_DESC)) ==FAIL) {
    print_ss_level2_data_2hr_error("init_cr_ss_level2_data_2hr -> ANcreate: Can't create Vgrp description");
    retval = -1;
  }
  if ((ANwriteann(ann_id_w, Vgrp_descrp_SS_data_2hr, sizeof(Vgrp_descrp_SS_data_2hr))) ==FAIL) {
    print_ss_level2_data_2hr_error("init_cr_ss_level2_data_2hr -> ANwriteann: Can't write Vgrp description");
    retval = -1;
  }
  ANendaccess(ann_id_w);

  /*        Setup a Vdata        */
  if ((vdata_id_ss_level2_data_2hr = VSattach(hdf_fp, -1, "w")) ==FAIL) {
    print_ss_level2_data_2hr_error("init_cr_ss_level2_data_2hr -> VSattach: Couldn't attach to Vdata");
    retval = -1;
  }
  VSsetname(vdata_id_ss_level2_data_2hr, "SS_data_2hr");
  VSsetclass(vdata_id_ss_level2_data_2hr, classname);

  /*       Insert the Vdata into the Vgroup       */
  if ((Vinsert(vgrp_id_ss_level2_data_2hr, vdata_id_ss_level2_data_2hr)) ==FAIL) {
    print_ss_level2_data_2hr_error("init_cr_ss_level2_data_2hr -> Vinsert: Couldn't insert Vdata into Vgroup");
    retval = -1;
  }

  /*    Define the fields in the Vdata    */
  if (VSfdefine(vdata_id_ss_level2_data_2hr, "year", DFNT_INT32, (1) )) {
    print_ss_level2_data_2hr_error("init_cr_ss_level2_data_2hr -> VSfdefine: Couldn't define year");
    retval = -1;
  }
  if (VSfdefine(vdata_id_ss_level2_data_2hr, "day", DFNT_INT32, (1) )) {
    print_ss_level2_data_2hr_error("init_cr_ss_level2_data_2hr -> VSfdefine: Couldn't define day");
    retval = -1;
  }
  if (VSfdefine(vdata_id_ss_level2_data_2hr, "hr", DFNT_INT32, (1) )) {
    print_ss_level2_data_2hr_error("init_cr_ss_level2_data_2hr -> VSfdefine: Couldn't define hr");
    retval = -1;
  }
  if (VSfdefine(vdata_id_ss_level2_data_2hr, "min", DFNT_INT32, (1) )) {
    print_ss_level2_data_2hr_error("init_cr_ss_level2_data_2hr -> VSfdefine: Couldn't define min");
    retval = -1;
  }
  if (VSfdefine(vdata_id_ss_level2_data_2hr, "sec", DFNT_FLOAT32, (1) )) {
    print_ss_level2_data_2hr_error("init_cr_ss_level2_data_2hr -> VSfdefine: Couldn't define sec");
    retval = -1;
  }
  if (VSfdefine(vdata_id_ss_level2_data_2hr, "fp_year", DFNT_FLOAT64, (1) )) {
    print_ss_level2_data_2hr_error("init_cr_ss_level2_data_2hr -> VSfdefine: Couldn't define fp_year");
    retval = -1;
  }
  if (VSfdefine(vdata_id_ss_level2_data_2hr, "fp_doy", DFNT_FLOAT64, (1) )) {
    print_ss_level2_data_2hr_error("init_cr_ss_level2_data_2hr -> VSfdefine: Couldn't define fp_doy");
    retval = -1;
  }
  if (VSfdefine(vdata_id_ss_level2_data_2hr, "ACEepoch", DFNT_FLOAT64, (1) )) {
    print_ss_level2_data_2hr_error("init_cr_ss_level2_data_2hr -> VSfdefine: Couldn't define ACEepoch");
    retval = -1;
  }
  if (VSfdefine(vdata_id_ss_level2_data_2hr, "nHe2", DFNT_FLOAT32, (1) )) {
    print_ss_level2_data_2hr_error("init_cr_ss_level2_data_2hr -> VSfdefine: Couldn't define nHe2");
    retval = -1;
  }
  if (VSfdefine(vdata_id_ss_level2_data_2hr, "vHe2", DFNT_FLOAT32, (1) )) {
    print_ss_level2_data_2hr_error("init_cr_ss_level2_data_2hr -> VSfdefine: Couldn't define vHe2");
    retval = -1;
  }
  if (VSfdefine(vdata_id_ss_level2_data_2hr, "vC5", DFNT_FLOAT32, (1) )) {
    print_ss_level2_data_2hr_error("init_cr_ss_level2_data_2hr -> VSfdefine: Couldn't define vC5");
    retval = -1;
  }
  if (VSfdefine(vdata_id_ss_level2_data_2hr, "vO6", DFNT_FLOAT32, (1) )) {
    print_ss_level2_data_2hr_error("init_cr_ss_level2_data_2hr -> VSfdefine: Couldn't define vO6");
    retval = -1;
  }
  if (VSfdefine(vdata_id_ss_level2_data_2hr, "vFe10", DFNT_FLOAT32, (1) )) {
    print_ss_level2_data_2hr_error("init_cr_ss_level2_data_2hr -> VSfdefine: Couldn't define vFe10");
    retval = -1;
  }
  if (VSfdefine(vdata_id_ss_level2_data_2hr, "vthHe2", DFNT_FLOAT32, (1) )) {
    print_ss_level2_data_2hr_error("init_cr_ss_level2_data_2hr -> VSfdefine: Couldn't define vthHe2");
    retval = -1;
  }
  if (VSfdefine(vdata_id_ss_level2_data_2hr, "vthC5", DFNT_FLOAT32, (1) )) {
    print_ss_level2_data_2hr_error("init_cr_ss_level2_data_2hr -> VSfdefine: Couldn't define vthC5");
    retval = -1;
  }
  if (VSfdefine(vdata_id_ss_level2_data_2hr, "vthO6", DFNT_FLOAT32, (1) )) {
    print_ss_level2_data_2hr_error("init_cr_ss_level2_data_2hr -> VSfdefine: Couldn't define vthO6");
    retval = -1;
  }
  if (VSfdefine(vdata_id_ss_level2_data_2hr, "vthFe10", DFNT_FLOAT32, (1) )) {
    print_ss_level2_data_2hr_error("init_cr_ss_level2_data_2hr -> VSfdefine: Couldn't define vthFe10");
    retval = -1;
  }
  if (VSfdefine(vdata_id_ss_level2_data_2hr, "He_qual", DFNT_INT16, (1) )) {
    print_ss_level2_data_2hr_error("init_cr_ss_level2_data_2hr -> VSfdefine: Couldn't define He_qual");
    retval = -1;
  }
  if (VSfdefine(vdata_id_ss_level2_data_2hr, "C5_qual", DFNT_INT16, (1) )) {
    print_ss_level2_data_2hr_error("init_cr_ss_level2_data_2hr -> VSfdefine: Couldn't define C5_qual");
    retval = -1;
  }
  if (VSfdefine(vdata_id_ss_level2_data_2hr, "O6_qual", DFNT_INT16, (1) )) {
    print_ss_level2_data_2hr_error("init_cr_ss_level2_data_2hr -> VSfdefine: Couldn't define O6_qual");
    retval = -1;
  }
  if (VSfdefine(vdata_id_ss_level2_data_2hr, "Fe10_qual", DFNT_INT16, (1) )) {
    print_ss_level2_data_2hr_error("init_cr_ss_level2_data_2hr -> VSfdefine: Couldn't define Fe10_qual");
    retval = -1;
  }
  if (VSfdefine(vdata_id_ss_level2_data_2hr, "C6to5", DFNT_FLOAT32, (1) )) {
    print_ss_level2_data_2hr_error("init_cr_ss_level2_data_2hr -> VSfdefine: Couldn't define C6to5");
    retval = -1;
  }
  if (VSfdefine(vdata_id_ss_level2_data_2hr, "O7to6", DFNT_FLOAT32, (1) )) {
    print_ss_level2_data_2hr_error("init_cr_ss_level2_data_2hr -> VSfdefine: Couldn't define O7to6");
    retval = -1;
  }
  if (VSfdefine(vdata_id_ss_level2_data_2hr, "avqC", DFNT_FLOAT32, (1) )) {
    print_ss_level2_data_2hr_error("init_cr_ss_level2_data_2hr -> VSfdefine: Couldn't define avqC");
    retval = -1;
  }
  if (VSfdefine(vdata_id_ss_level2_data_2hr, "avqO", DFNT_FLOAT32, (1) )) {
    print_ss_level2_data_2hr_error("init_cr_ss_level2_data_2hr -> VSfdefine: Couldn't define avqO");
    retval = -1;
  }
  if (VSfdefine(vdata_id_ss_level2_data_2hr, "avqFe", DFNT_FLOAT32, (1) )) {
    print_ss_level2_data_2hr_error("init_cr_ss_level2_data_2hr -> VSfdefine: Couldn't define avqFe");
    retval = -1;
  }
  if (VSfdefine(vdata_id_ss_level2_data_2hr, "C6to5_qual", DFNT_INT16, (1) )) {
    print_ss_level2_data_2hr_error("init_cr_ss_level2_data_2hr -> VSfdefine: Couldn't define C6to5_qual");
    retval = -1;
  }
  if (VSfdefine(vdata_id_ss_level2_data_2hr, "O7to6_qual", DFNT_INT16, (1) )) {
    print_ss_level2_data_2hr_error("init_cr_ss_level2_data_2hr -> VSfdefine: Couldn't define O7to6_qual");
    retval = -1;
  }
  if (VSfdefine(vdata_id_ss_level2_data_2hr, "avqC_qual", DFNT_INT16, (1) )) {
    print_ss_level2_data_2hr_error("init_cr_ss_level2_data_2hr -> VSfdefine: Couldn't define avqC_qual");
    retval = -1;
  }
  if (VSfdefine(vdata_id_ss_level2_data_2hr, "avqO_qual", DFNT_INT16, (1) )) {
    print_ss_level2_data_2hr_error("init_cr_ss_level2_data_2hr -> VSfdefine: Couldn't define avqO_qual");
    retval = -1;
  }
  if (VSfdefine(vdata_id_ss_level2_data_2hr, "avqFe_qual", DFNT_INT16, (1) )) {
    print_ss_level2_data_2hr_error("init_cr_ss_level2_data_2hr -> VSfdefine: Couldn't define avqFe_qual");
    retval = -1;
  }
  if (VSfdefine(vdata_id_ss_level2_data_2hr, "SW_type", DFNT_INT16, (1) )) {
    print_ss_level2_data_2hr_error("init_cr_ss_level2_data_2hr -> VSfdefine: Couldn't define SW_type");
    retval = -1;
  }
  if (VSfdefine(vdata_id_ss_level2_data_2hr, "FetoO", DFNT_FLOAT32, (1) )) {
    print_ss_level2_data_2hr_error("init_cr_ss_level2_data_2hr -> VSfdefine: Couldn't define FetoO");
    retval = -1;
  }
  if (VSfdefine(vdata_id_ss_level2_data_2hr, "FetoO_qual", DFNT_INT16, (1) )) {
    print_ss_level2_data_2hr_error("init_cr_ss_level2_data_2hr -> VSfdefine: Couldn't define FetoO_qual");
    retval = -1;
  }
  if (VSfdefine(vdata_id_ss_level2_data_2hr, "HetoO", DFNT_FLOAT32, (1) )) {
    print_ss_level2_data_2hr_error("init_cr_ss_level2_data_2hr -> VSfdefine: Couldn't define HetoO");
    retval = -1;
  }
  if (VSfdefine(vdata_id_ss_level2_data_2hr, "HetoO_qual", DFNT_INT16, (1) )) {
    print_ss_level2_data_2hr_error("init_cr_ss_level2_data_2hr -> VSfdefine: Couldn't define HetoO_qual");
    retval = -1;
  }
  if (VSfdefine(vdata_id_ss_level2_data_2hr, "CtoO", DFNT_FLOAT32, (1) )) {
    print_ss_level2_data_2hr_error("init_cr_ss_level2_data_2hr -> VSfdefine: Couldn't define CtoO");
    retval = -1;
  }
  if (VSfdefine(vdata_id_ss_level2_data_2hr, "CtoO_qual", DFNT_INT16, (1) )) {
    print_ss_level2_data_2hr_error("init_cr_ss_level2_data_2hr -> VSfdefine: Couldn't define CtoO_qual");
    retval = -1;
  }
  if (VSfdefine(vdata_id_ss_level2_data_2hr, "NetoO", DFNT_FLOAT32, (1) )) {
    print_ss_level2_data_2hr_error("init_cr_ss_level2_data_2hr -> VSfdefine: Couldn't define NetoO");
    retval = -1;
  }
  if (VSfdefine(vdata_id_ss_level2_data_2hr, "NetoO_qual", DFNT_INT16, (1) )) {
    print_ss_level2_data_2hr_error("init_cr_ss_level2_data_2hr -> VSfdefine: Couldn't define NetoO_qual");
    retval = -1;
  }
  if (VSfdefine(vdata_id_ss_level2_data_2hr, "MgtoO", DFNT_FLOAT32, (1) )) {
    print_ss_level2_data_2hr_error("init_cr_ss_level2_data_2hr -> VSfdefine: Couldn't define MgtoO");
    retval = -1;
  }
  if (VSfdefine(vdata_id_ss_level2_data_2hr, "MgtoO_qual", DFNT_INT16, (1) )) {
    print_ss_level2_data_2hr_error("init_cr_ss_level2_data_2hr -> VSfdefine: Couldn't define MgtoO_qual");
    retval = -1;
  }
  if (VSfdefine(vdata_id_ss_level2_data_2hr, "SitoO", DFNT_FLOAT32, (1) )) {
    print_ss_level2_data_2hr_error("init_cr_ss_level2_data_2hr -> VSfdefine: Couldn't define SitoO");
    retval = -1;
  }
  if (VSfdefine(vdata_id_ss_level2_data_2hr, "SitoO_qual", DFNT_INT16, (1) )) {
    print_ss_level2_data_2hr_error("init_cr_ss_level2_data_2hr -> VSfdefine: Couldn't define SitoO_qual");
    retval = -1;
  }

  if (VSsetfields(vdata_id_ss_level2_data_2hr,"year, day, hr, min, sec, fp_year, fp_doy, ACEepoch, nHe2, vHe2, vC5, vO6, vFe10, vthHe2, vthC5, vthO6, vthFe10, He_qual, C5_qual, O6_qual, Fe10_qual, C6to5, O7to6, avqC, avqO, avqFe, C6to5_qual, O7to6_qual, avqC_qual, avqO_qual, avqFe_qual, SW_type, FetoO, FetoO_qual, HetoO, HetoO_qual, CtoO, CtoO_qual, NetoO, NetoO_qual, MgtoO, MgtoO_qual, SitoO, SitoO_qual")){
    print_ss_level2_data_2hr_error("init_cr_ss_level2_data_2hr -> VSsetfields: Couldn't set fields");
    retval = -1;
  }

  return(retval);
}

/* Included for backwards compatibility */

int32 init_wr_ss_level2_data_2hr(int32 hdf_fp, int32 sd_id, int32 an_id, char *classname)
{ return( init_cr_ss_level2_data_2hr(hdf_fp, sd_id, an_id, classname) ); }

/******---- write function ----******/

int32 write_ss_level2_data_2hr(struct SS_data_2hr SS_data_2hr_struc, int32 recnum)
{
  int32 retval = 0;
  uint8 *odata;

void print_ss_level2_data_2hr_error();
void pack_ss_level2_data_2hr();

  odata = (uint8 *) malloc(sizeof(struct SS_data_2hr));
  pack_ss_level2_data_2hr(odata, &SS_data_2hr_struc);

  if(recnum!=-1) {
	if(VSseek(vdata_id_ss_level2_data_2hr, recnum)==-1) {
		print_ss_level2_data_2hr_error("write_ss_level2_data_2hr -> VSseek: error.");
		retval = -1;
	}
  }
  if(VSwrite(vdata_id_ss_level2_data_2hr, (uint8 *)odata, 1, FULL_INTERLACE) == -1)
    print_ss_level2_data_2hr_error("write_ss_level2_data_2hr -> VSwrite: Couldn't write data.");

  memset(&SS_data_2hr_struc, 0, sizeof(struct SS_data_2hr));
  free(odata);
  return(retval);
}

/*----   close write function    ----*/

void close_wr_ss_level2_data_2hr()
{
  VSdetach(vdata_id_ss_level2_data_2hr);
  Vdetach(vgrp_id_ss_level2_data_2hr);
}

/*----     init access function    ----*/

int32 init_acc_ss_level2_data_2hr(int32 hdf_fp, int32 sd_id, char *access_mode)
{
  int32 vdata_ref;
  int32 num_rec;

  void print_ss_level2_data_2hr_error();


  if ((vdata_ref = VSfind(hdf_fp, "SS_data_2hr")) <= 0 ) {
    print_ss_level2_data_2hr_error("init_acc_ss_level2_data_2hr -> VSfind: Found no vdata of specified type.");
    return(0);
  }
  if ((vdata_id_ss_level2_data_2hr = VSattach(hdf_fp, vdata_ref, access_mode)) ==FAIL) {
    print_ss_level2_data_2hr_error("init_acc_ss_level2_data_2hr -> VSattach: Couldn't attach to hdf file.");
    return(-1);
  }

  VSinquire(vdata_id_ss_level2_data_2hr, &num_rec, NULL, NULL, NULL, NULL);
  if (num_rec == 0) { return(0); }


  if (VSsetfields(vdata_id_ss_level2_data_2hr,"year, day, hr, min, sec, fp_year, fp_doy, ACEepoch, nHe2, vHe2, vC5, vO6, vFe10, vthHe2, vthC5, vthO6, vthFe10, He_qual, C5_qual, O6_qual, Fe10_qual, C6to5, O7to6, avqC, avqO, avqFe, C6to5_qual, O7to6_qual, avqC_qual, avqO_qual, avqFe_qual, SW_type, FetoO, FetoO_qual, HetoO, HetoO_qual, CtoO, CtoO_qual, NetoO, NetoO_qual, MgtoO, MgtoO_qual, SitoO, SitoO_qual")) {
      print_ss_level2_data_2hr_error("init_acc_ss_level2_data_2hr -> VSsetfields: Unable to set fields.");
      return(-1);
  }
  return(num_rec);
}

/* Included for backwards compatability */

int32 init_rd_ss_level2_data_2hr(int32 hdf_fp, int32 sd_id, char *access_mode)
{ return ( init_acc_ss_level2_data_2hr(hdf_fp, sd_id, access_mode) ); }

/******---- read function ----******/

int32 read_ss_level2_data_2hr(struct SS_data_2hr *SS_data_2hr_struc, int32 recnum_rd)
{
int32 maxrec;
static int32 last_recnum = -1;
int32 retval = 0;
uint8 *odata;

void print_ss_level2_data_2hr_error();
void unpack_ss_level2_data_2hr();

  if(recnum_rd==-1) recnum_rd=last_recnum+1;

  odata = (uint8 *) malloc(sizeof(struct SS_data_2hr));
  VSinquire(vdata_id_ss_level2_data_2hr, &maxrec, NULL, NULL, NULL, NULL);
  if (recnum_rd >= maxrec) return(-1);
  if (recnum_rd != last_recnum+1)
      if (VSseek(vdata_id_ss_level2_data_2hr, recnum_rd)==FAIL) {
          print_ss_level2_data_2hr_error("read_ss_level2_data_2hr -> VSseek unsuccessful");
          retval = -1;
    }
  last_recnum = recnum_rd;

  if(VSread(vdata_id_ss_level2_data_2hr, (uint8 *)odata, 1, FULL_INTERLACE) ==FAIL) {
    print_ss_level2_data_2hr_error("read_ss_level2_data_2hr -> VSread: Couldn't read data.");
    retval = -1;
  }
  unpack_ss_level2_data_2hr(odata, SS_data_2hr_struc);
  free(odata);
  return(retval);
}

/*----   close read function    ----*/

void close_rd_ss_level2_data_2hr()
{
  VSdetach(vdata_id_ss_level2_data_2hr);
}

/*----  Read V group description, function    ----*/
void rd_Vgrp_desc_ss_level2_data_2hr(int32 hdf_fp, int32 an_id)
{
  int32 ann_id_r;
  int32 num_ann;
  int32 *ann_list;
  int32 vgrp_ref_r;

void print_ss_level2_data_2hr_error();

  /*      Get the Vgroup reference     */
  if ((vgrp_ref_r = Vfind(hdf_fp, "VG_SS_data_2hr" )) ==FAIL)
    print_ss_level2_data_2hr_error("rd_Vgrp_ss_level2_data_2hr -> Vfind: Couldn't get Vgrp reference.");

  if ((num_ann = ANnumann(an_id, AN_DATA_DESC, DFTAG_VG, vgrp_ref_r)) ==FAIL)
    print_ss_level2_data_2hr_error("rd_Vgrp_ss_level2_data_2hr -> ANnumann: Couldn't get number of annotations.");

    ann_list = HDmalloc(num_ann * sizeof(int32));
  if ((num_ann = ANannlist(an_id, AN_DATA_DESC, DFTAG_VG, vgrp_ref_r, ann_list)) ==FAIL)
    print_ss_level2_data_2hr_error("rd_Vgrp_ss_level2_data_2hr -> ANannlist: Couldn't");

  if ((ann_id_r = ANselect(an_id, (num_ann-1), AN_DATA_DESC)) ==FAIL)
    print_ss_level2_data_2hr_error("rd_Vgrp_ss_level2_data_2hr -> ANselect: Couldn't");

  if (ANreadann(ann_id_r, Vgrp_descrp_SS_data_2hr, HDstrlen(Vgrp_descrp_SS_data_2hr)) ==FAIL)
    print_ss_level2_data_2hr_error("rd_Vgrp_ss_level2_data_2hr -> ANreadann: Couldn't");

  printf("AN: %s\n", Vgrp_descrp_SS_data_2hr);
  ANendaccess(ann_id_r);
  ANend(an_id);
}

/*----   error function    ----*/

void print_ss_level2_data_2hr_error(int8 *mess)
{
  fprintf(stderr,"\nERROR in  hdf_ss_level2_data_2hr.c -> %s\n", mess);
  HEprint(stderr, 0);
}

/*----   pack function    ----*/

void pack_ss_level2_data_2hr(uint8 *data, struct SS_data_2hr *SS_data_2hr_ptr)
{
int32 ptr=0;

   memcpy(data+ptr, &SS_data_2hr_ptr->year, ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(data+ptr, &SS_data_2hr_ptr->day, ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(data+ptr, &SS_data_2hr_ptr->hr, ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(data+ptr, &SS_data_2hr_ptr->min, ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(data+ptr, &SS_data_2hr_ptr->sec, ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(data+ptr, &SS_data_2hr_ptr->fp_year, ((8)*(1)) );
   ptr+= ((8)*(1));
   memcpy(data+ptr, &SS_data_2hr_ptr->fp_doy, ((8)*(1)) );
   ptr+= ((8)*(1));
   memcpy(data+ptr, &SS_data_2hr_ptr->ACEepoch, ((8)*(1)) );
   ptr+= ((8)*(1));
   memcpy(data+ptr, &SS_data_2hr_ptr->nHe2, ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(data+ptr, &SS_data_2hr_ptr->vHe2, ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(data+ptr, &SS_data_2hr_ptr->vC5, ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(data+ptr, &SS_data_2hr_ptr->vO6, ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(data+ptr, &SS_data_2hr_ptr->vFe10, ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(data+ptr, &SS_data_2hr_ptr->vthHe2, ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(data+ptr, &SS_data_2hr_ptr->vthC5, ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(data+ptr, &SS_data_2hr_ptr->vthO6, ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(data+ptr, &SS_data_2hr_ptr->vthFe10, ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(data+ptr, &SS_data_2hr_ptr->He_qual, ((2)*(1)) );
   ptr+= ((2)*(1));
   memcpy(data+ptr, &SS_data_2hr_ptr->C5_qual, ((2)*(1)) );
   ptr+= ((2)*(1));
   memcpy(data+ptr, &SS_data_2hr_ptr->O6_qual, ((2)*(1)) );
   ptr+= ((2)*(1));
   memcpy(data+ptr, &SS_data_2hr_ptr->Fe10_qual, ((2)*(1)) );
   ptr+= ((2)*(1));
   memcpy(data+ptr, &SS_data_2hr_ptr->C6to5, ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(data+ptr, &SS_data_2hr_ptr->O7to6, ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(data+ptr, &SS_data_2hr_ptr->avqC, ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(data+ptr, &SS_data_2hr_ptr->avqO, ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(data+ptr, &SS_data_2hr_ptr->avqFe, ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(data+ptr, &SS_data_2hr_ptr->C6to5_qual, ((2)*(1)) );
   ptr+= ((2)*(1));
   memcpy(data+ptr, &SS_data_2hr_ptr->O7to6_qual, ((2)*(1)) );
   ptr+= ((2)*(1));
   memcpy(data+ptr, &SS_data_2hr_ptr->avqC_qual, ((2)*(1)) );
   ptr+= ((2)*(1));
   memcpy(data+ptr, &SS_data_2hr_ptr->avqO_qual, ((2)*(1)) );
   ptr+= ((2)*(1));
   memcpy(data+ptr, &SS_data_2hr_ptr->avqFe_qual, ((2)*(1)) );
   ptr+= ((2)*(1));
   memcpy(data+ptr, &SS_data_2hr_ptr->SW_type, ((2)*(1)) );
   ptr+= ((2)*(1));
   memcpy(data+ptr, &SS_data_2hr_ptr->FetoO, ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(data+ptr, &SS_data_2hr_ptr->FetoO_qual, ((2)*(1)) );
   ptr+= ((2)*(1));
   memcpy(data+ptr, &SS_data_2hr_ptr->HetoO, ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(data+ptr, &SS_data_2hr_ptr->HetoO_qual, ((2)*(1)) );
   ptr+= ((2)*(1));
   memcpy(data+ptr, &SS_data_2hr_ptr->CtoO, ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(data+ptr, &SS_data_2hr_ptr->CtoO_qual, ((2)*(1)) );
   ptr+= ((2)*(1));
   memcpy(data+ptr, &SS_data_2hr_ptr->NetoO, ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(data+ptr, &SS_data_2hr_ptr->NetoO_qual, ((2)*(1)) );
   ptr+= ((2)*(1));
   memcpy(data+ptr, &SS_data_2hr_ptr->MgtoO, ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(data+ptr, &SS_data_2hr_ptr->MgtoO_qual, ((2)*(1)) );
   ptr+= ((2)*(1));
   memcpy(data+ptr, &SS_data_2hr_ptr->SitoO, ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(data+ptr, &SS_data_2hr_ptr->SitoO_qual, ((2)*(1)) );
   ptr+= ((2)*(1));
}

/*----   unpack function    ----*/

void unpack_ss_level2_data_2hr(uint8 *data, struct SS_data_2hr *SS_data_2hr_ptr)
{
int32 ptr=0;

   memcpy(&SS_data_2hr_ptr->year, data+ptr,  ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(&SS_data_2hr_ptr->day, data+ptr,  ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(&SS_data_2hr_ptr->hr, data+ptr,  ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(&SS_data_2hr_ptr->min, data+ptr,  ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(&SS_data_2hr_ptr->sec, data+ptr,  ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(&SS_data_2hr_ptr->fp_year, data+ptr,  ((8)*(1)) );
   ptr+= ((8)*(1));
   memcpy(&SS_data_2hr_ptr->fp_doy, data+ptr,  ((8)*(1)) );
   ptr+= ((8)*(1));
   memcpy(&SS_data_2hr_ptr->ACEepoch, data+ptr,  ((8)*(1)) );
   ptr+= ((8)*(1));
   memcpy(&SS_data_2hr_ptr->nHe2, data+ptr,  ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(&SS_data_2hr_ptr->vHe2, data+ptr,  ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(&SS_data_2hr_ptr->vC5, data+ptr,  ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(&SS_data_2hr_ptr->vO6, data+ptr,  ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(&SS_data_2hr_ptr->vFe10, data+ptr,  ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(&SS_data_2hr_ptr->vthHe2, data+ptr,  ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(&SS_data_2hr_ptr->vthC5, data+ptr,  ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(&SS_data_2hr_ptr->vthO6, data+ptr,  ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(&SS_data_2hr_ptr->vthFe10, data+ptr,  ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(&SS_data_2hr_ptr->He_qual, data+ptr,  ((2)*(1)) );
   ptr+= ((2)*(1));
   memcpy(&SS_data_2hr_ptr->C5_qual, data+ptr,  ((2)*(1)) );
   ptr+= ((2)*(1));
   memcpy(&SS_data_2hr_ptr->O6_qual, data+ptr,  ((2)*(1)) );
   ptr+= ((2)*(1));
   memcpy(&SS_data_2hr_ptr->Fe10_qual, data+ptr,  ((2)*(1)) );
   ptr+= ((2)*(1));
   memcpy(&SS_data_2hr_ptr->C6to5, data+ptr,  ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(&SS_data_2hr_ptr->O7to6, data+ptr,  ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(&SS_data_2hr_ptr->avqC, data+ptr,  ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(&SS_data_2hr_ptr->avqO, data+ptr,  ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(&SS_data_2hr_ptr->avqFe, data+ptr,  ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(&SS_data_2hr_ptr->C6to5_qual, data+ptr,  ((2)*(1)) );
   ptr+= ((2)*(1));
   memcpy(&SS_data_2hr_ptr->O7to6_qual, data+ptr,  ((2)*(1)) );
   ptr+= ((2)*(1));
   memcpy(&SS_data_2hr_ptr->avqC_qual, data+ptr,  ((2)*(1)) );
   ptr+= ((2)*(1));
   memcpy(&SS_data_2hr_ptr->avqO_qual, data+ptr,  ((2)*(1)) );
   ptr+= ((2)*(1));
   memcpy(&SS_data_2hr_ptr->avqFe_qual, data+ptr,  ((2)*(1)) );
   ptr+= ((2)*(1));
   memcpy(&SS_data_2hr_ptr->SW_type, data+ptr,  ((2)*(1)) );
   ptr+= ((2)*(1));
   memcpy(&SS_data_2hr_ptr->FetoO, data+ptr,  ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(&SS_data_2hr_ptr->FetoO_qual, data+ptr,  ((2)*(1)) );
   ptr+= ((2)*(1));
   memcpy(&SS_data_2hr_ptr->HetoO, data+ptr,  ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(&SS_data_2hr_ptr->HetoO_qual, data+ptr,  ((2)*(1)) );
   ptr+= ((2)*(1));
   memcpy(&SS_data_2hr_ptr->CtoO, data+ptr,  ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(&SS_data_2hr_ptr->CtoO_qual, data+ptr,  ((2)*(1)) );
   ptr+= ((2)*(1));
   memcpy(&SS_data_2hr_ptr->NetoO, data+ptr,  ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(&SS_data_2hr_ptr->NetoO_qual, data+ptr,  ((2)*(1)) );
   ptr+= ((2)*(1));
   memcpy(&SS_data_2hr_ptr->MgtoO, data+ptr,  ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(&SS_data_2hr_ptr->MgtoO_qual, data+ptr,  ((2)*(1)) );
   ptr+= ((2)*(1));
   memcpy(&SS_data_2hr_ptr->SitoO, data+ptr,  ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(&SS_data_2hr_ptr->SitoO_qual, data+ptr,  ((2)*(1)) );
   ptr+= ((2)*(1));
}
int32 get_vgrp_id_ss_level2_data_2hr() {return(vgrp_id_ss_level2_data_2hr);}

/*----   V group description function    ----*/

int32 wr_Vgrp_desc_ss_level2_data_2hr(char *wr_strval)
{
  strcpy(wr_strval, "The file 'ss_level2_data_2hr.h' is shown below, it was used to create the data in the Vgroup named 'VG_SS_data_2hr'.\n\n");
  strcat(wr_strval,"/* Id:$ */\n");
  strcat(wr_strval,"\n");
  strcat(wr_strval,"#include \"hdfi.h\"\n");
  strcat(wr_strval,"\n");
  strcat(wr_strval,"struct SS_data_2hr {\n");
  strcat(wr_strval,"\n");
  strcat(wr_strval,"  /* UT time at the start of each record */\n");
  strcat(wr_strval,"  int32   year;                         /* integer year */\n");
  strcat(wr_strval,"  int32   day;                          /* integer day of year */\n");
  strcat(wr_strval,"  int32   hr;                           /* hour of day */\n");
  strcat(wr_strval,"  int32   min;                          /* min of hour */\n");
  strcat(wr_strval,"  float32 sec;                          /* seconds of minute */\n");
  strcat(wr_strval,"  float64 fp_year;                      /* floating point year */\n");
  strcat(wr_strval,"  float64 fp_doy;                       /* floating point Day of Year */ \n");
  strcat(wr_strval,"  float64 ACEepoch;                     /* UT time in sec since 1/1/96 */\n");
  strcat(wr_strval,"\n");
  strcat(wr_strval,"  float32 nHe2;\n");
  strcat(wr_strval,"\n");
  strcat(wr_strval,"  float32 vHe2;\n");
  strcat(wr_strval,"  float32 vC5;\n");
  strcat(wr_strval,"  float32 vO6;\n");
  strcat(wr_strval,"  float32 vFe10;\n");
  strcat(wr_strval,"\n");
  strcat(wr_strval,"  float32 vthHe2;\n");
  strcat(wr_strval,"  float32 vthC5;\n");
  strcat(wr_strval,"  float32 vthO6;\n");
  strcat(wr_strval,"  float32 vthFe10;\n");
  strcat(wr_strval,"\n");
  strcat(wr_strval,"  int16 He_qual;\n");
  strcat(wr_strval,"  int16 C5_qual;\n");
  strcat(wr_strval,"  int16 O6_qual;\n");
  strcat(wr_strval,"  int16 Fe10_qual;\n");
  strcat(wr_strval,"\n");
  strcat(wr_strval,"  float32 C6to5;\n");
  strcat(wr_strval,"  float32 O7to6;\n");
  strcat(wr_strval,"  float32 avqC;\n");
  strcat(wr_strval,"  float32 avqO;\n");
  strcat(wr_strval,"  float32 avqFe;\n");
  strcat(wr_strval,"\n");
  strcat(wr_strval,"  int16 C6to5_qual;\n");
  strcat(wr_strval,"  int16 O7to6_qual;\n");
  strcat(wr_strval,"  int16 avqC_qual;\n");
  strcat(wr_strval,"  int16 avqO_qual;\n");
  strcat(wr_strval,"  int16 avqFe_qual;\n");
  strcat(wr_strval,"\n");
  strcat(wr_strval,"  int16 SW_type; /* Solar wind type indicator */\n");
  strcat(wr_strval,"\n");
  strcat(wr_strval,"  float32 FetoO;\n");
  strcat(wr_strval,"  int16 FetoO_qual;\n");
  strcat(wr_strval,"\n");
  strcat(wr_strval,"  /* everything above here should be just like the 1hr data */\n");
  strcat(wr_strval,"\n");
  strcat(wr_strval,"  float32 HetoO;\n");
  strcat(wr_strval,"  int16 HetoO_qual;\n");
  strcat(wr_strval,"\n");
  strcat(wr_strval,"  float32 CtoO;\n");
  strcat(wr_strval,"  int16 CtoO_qual;\n");
  strcat(wr_strval,"\n");
  strcat(wr_strval,"  float32 NetoO;\n");
  strcat(wr_strval,"  int16 NetoO_qual;\n");
  strcat(wr_strval,"\n");
  strcat(wr_strval,"  float32 MgtoO;\n");
  strcat(wr_strval,"  int16 MgtoO_qual;\n");
  strcat(wr_strval,"\n");
  strcat(wr_strval,"  float32 SitoO;\n");
  strcat(wr_strval,"  int16 SitoO_qual;\n");
  strcat(wr_strval,"  \n");
  strcat(wr_strval,"};\n");
  strcat(wr_strval,"\n");
  strcat(wr_strval,"\n");
  strcat(wr_strval,"\n");
  strcat(wr_strval,"\n");
  strcat(wr_strval,"\n");
  strcat(wr_strval,"\n");
  strcat(wr_strval,"\n");
  strcat(wr_strval,"\n");
  strcat(wr_strval,"\n");
  strcat(wr_strval,"\n");
  strcat(wr_strval,"\n");
  strcat(wr_strval,"\n");
  return(0);
}
