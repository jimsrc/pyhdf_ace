/* The RCS version of hdfgen.pl used to create this file is: */
/* $Id: hdfgen.pl,v 1.49 1999/11/04 17:17:13 asc Exp  */

/* The include file used to create this file is: */
/* $Id: sis_level2_data_1day.h,v 1.1 2000/08/02 00:50:30 asc Exp asc  */

#include "sis_level2_data_1day.h"
#include "df.h"

int32 vgrp_id_sis_level2_all_1day;
static int32 vdata_id_sis_level2_all_1day;

  /* 2280 is the size of sis_level2_data_1day.h + 1 added line */
char Vgrp_descrp_SIS_data_1day[2280];

/****----  init create function  ----****/

int32 init_cr_sis_level2_all_1day(int32 hdf_fp, int32 sd_id, int32 an_id, char *classname)
{
  int32 retval=0;
  int32 vgrp_ref_w;
  int32 ann_id_w;
  int32 wr_Vgrp_desc_sis_level2_all_1day();

  void print_sis_level2_all_1day_error();

  /*         Setup a Vgroup         */
  if ((vgrp_id_sis_level2_all_1day = Vattach(hdf_fp, -1, "w"))==FAIL) {
    print_sis_level2_all_1day_error("init_cr_sis_level2_all_1day -> Vattach: Couldn't create Vgroup");
    retval = -1;
  }
  Vsetname(vgrp_id_sis_level2_all_1day, "VG_SIS_data_1day"); 
  Vsetclass(vgrp_id_sis_level2_all_1day, "VG_SIS_LEVEL2_DATA_1DAY");


  /*      Get the Vgroup reference     */
  if ((vgrp_ref_w = Vfind(hdf_fp, "VG_SIS_data_1day" )) ==FAIL) {
    print_sis_level2_all_1day_error("init_cr_sis_level2_all_1day -> Vfind: Couldn't get Vgrp reference");
    retval = -1;
  }
  /*      Add a description to the Vgroup      */
  wr_Vgrp_desc_sis_level2_all_1day(Vgrp_descrp_SIS_data_1day);

  if ((ann_id_w = ANcreate(an_id, DFTAG_VG, vgrp_ref_w, AN_DATA_DESC)) ==FAIL) {
    print_sis_level2_all_1day_error("init_cr_sis_level2_all_1day -> ANcreate: Can't create Vgrp description");
    retval = -1;
  }
  if ((ANwriteann(ann_id_w, Vgrp_descrp_SIS_data_1day, sizeof(Vgrp_descrp_SIS_data_1day))) ==FAIL) {
    print_sis_level2_all_1day_error("init_cr_sis_level2_all_1day -> ANwriteann: Can't write Vgrp description");
    retval = -1;
  }
  ANendaccess(ann_id_w);

  /*        Setup a Vdata        */
  if ((vdata_id_sis_level2_all_1day = VSattach(hdf_fp, -1, "w")) ==FAIL) {
    print_sis_level2_all_1day_error("init_cr_sis_level2_all_1day -> VSattach: Couldn't attach to Vdata");
    retval = -1;
  }
  VSsetname(vdata_id_sis_level2_all_1day, "SIS_data_1day");
  VSsetclass(vdata_id_sis_level2_all_1day, classname);

  /*       Insert the Vdata into the Vgroup       */
  if ((Vinsert(vgrp_id_sis_level2_all_1day, vdata_id_sis_level2_all_1day)) ==FAIL) {
    print_sis_level2_all_1day_error("init_cr_sis_level2_all_1day -> Vinsert: Couldn't insert Vdata into Vgroup");
    retval = -1;
  }

  /*    Define the fields in the Vdata    */
  if (VSfdefine(vdata_id_sis_level2_all_1day, "year", DFNT_INT32, (1) )) {
    print_sis_level2_all_1day_error("init_cr_sis_level2_all_1day -> VSfdefine: Couldn't define year");
    retval = -1;
  }
  if (VSfdefine(vdata_id_sis_level2_all_1day, "day", DFNT_INT32, (1) )) {
    print_sis_level2_all_1day_error("init_cr_sis_level2_all_1day -> VSfdefine: Couldn't define day");
    retval = -1;
  }
  if (VSfdefine(vdata_id_sis_level2_all_1day, "hr", DFNT_INT32, (1) )) {
    print_sis_level2_all_1day_error("init_cr_sis_level2_all_1day -> VSfdefine: Couldn't define hr");
    retval = -1;
  }
  if (VSfdefine(vdata_id_sis_level2_all_1day, "min", DFNT_INT32, (1) )) {
    print_sis_level2_all_1day_error("init_cr_sis_level2_all_1day -> VSfdefine: Couldn't define min");
    retval = -1;
  }
  if (VSfdefine(vdata_id_sis_level2_all_1day, "sec", DFNT_FLOAT32, (1) )) {
    print_sis_level2_all_1day_error("init_cr_sis_level2_all_1day -> VSfdefine: Couldn't define sec");
    retval = -1;
  }
  if (VSfdefine(vdata_id_sis_level2_all_1day, "fp_year", DFNT_FLOAT64, (1) )) {
    print_sis_level2_all_1day_error("init_cr_sis_level2_all_1day -> VSfdefine: Couldn't define fp_year");
    retval = -1;
  }
  if (VSfdefine(vdata_id_sis_level2_all_1day, "fp_doy", DFNT_FLOAT64, (1) )) {
    print_sis_level2_all_1day_error("init_cr_sis_level2_all_1day -> VSfdefine: Couldn't define fp_doy");
    retval = -1;
  }
  if (VSfdefine(vdata_id_sis_level2_all_1day, "ACEepoch", DFNT_FLOAT64, (1) )) {
    print_sis_level2_all_1day_error("init_cr_sis_level2_all_1day -> VSfdefine: Couldn't define ACEepoch");
    retval = -1;
  }
  if (VSfdefine(vdata_id_sis_level2_all_1day, "flux_He", DFNT_FLOAT32, (NUMBER_OF_ENERGY_BANDS) )) {
    print_sis_level2_all_1day_error("init_cr_sis_level2_all_1day -> VSfdefine: Couldn't define flux_He");
    retval = -1;
  }
  if (VSfdefine(vdata_id_sis_level2_all_1day, "flux_C", DFNT_FLOAT32, (NUMBER_OF_ENERGY_BANDS) )) {
    print_sis_level2_all_1day_error("init_cr_sis_level2_all_1day -> VSfdefine: Couldn't define flux_C");
    retval = -1;
  }
  if (VSfdefine(vdata_id_sis_level2_all_1day, "flux_N", DFNT_FLOAT32, (NUMBER_OF_ENERGY_BANDS) )) {
    print_sis_level2_all_1day_error("init_cr_sis_level2_all_1day -> VSfdefine: Couldn't define flux_N");
    retval = -1;
  }
  if (VSfdefine(vdata_id_sis_level2_all_1day, "flux_O", DFNT_FLOAT32, (NUMBER_OF_ENERGY_BANDS) )) {
    print_sis_level2_all_1day_error("init_cr_sis_level2_all_1day -> VSfdefine: Couldn't define flux_O");
    retval = -1;
  }
  if (VSfdefine(vdata_id_sis_level2_all_1day, "flux_Ne", DFNT_FLOAT32, (NUMBER_OF_ENERGY_BANDS) )) {
    print_sis_level2_all_1day_error("init_cr_sis_level2_all_1day -> VSfdefine: Couldn't define flux_Ne");
    retval = -1;
  }
  if (VSfdefine(vdata_id_sis_level2_all_1day, "flux_Na", DFNT_FLOAT32, (NUMBER_OF_ENERGY_BANDS) )) {
    print_sis_level2_all_1day_error("init_cr_sis_level2_all_1day -> VSfdefine: Couldn't define flux_Na");
    retval = -1;
  }
  if (VSfdefine(vdata_id_sis_level2_all_1day, "flux_Mg", DFNT_FLOAT32, (NUMBER_OF_ENERGY_BANDS) )) {
    print_sis_level2_all_1day_error("init_cr_sis_level2_all_1day -> VSfdefine: Couldn't define flux_Mg");
    retval = -1;
  }
  if (VSfdefine(vdata_id_sis_level2_all_1day, "flux_Al", DFNT_FLOAT32, (NUMBER_OF_ENERGY_BANDS) )) {
    print_sis_level2_all_1day_error("init_cr_sis_level2_all_1day -> VSfdefine: Couldn't define flux_Al");
    retval = -1;
  }
  if (VSfdefine(vdata_id_sis_level2_all_1day, "flux_Si", DFNT_FLOAT32, (NUMBER_OF_ENERGY_BANDS) )) {
    print_sis_level2_all_1day_error("init_cr_sis_level2_all_1day -> VSfdefine: Couldn't define flux_Si");
    retval = -1;
  }
  if (VSfdefine(vdata_id_sis_level2_all_1day, "flux_S", DFNT_FLOAT32, (NUMBER_OF_ENERGY_BANDS) )) {
    print_sis_level2_all_1day_error("init_cr_sis_level2_all_1day -> VSfdefine: Couldn't define flux_S");
    retval = -1;
  }
  if (VSfdefine(vdata_id_sis_level2_all_1day, "flux_Ar", DFNT_FLOAT32, (NUMBER_OF_ENERGY_BANDS) )) {
    print_sis_level2_all_1day_error("init_cr_sis_level2_all_1day -> VSfdefine: Couldn't define flux_Ar");
    retval = -1;
  }
  if (VSfdefine(vdata_id_sis_level2_all_1day, "flux_Ca", DFNT_FLOAT32, (NUMBER_OF_ENERGY_BANDS) )) {
    print_sis_level2_all_1day_error("init_cr_sis_level2_all_1day -> VSfdefine: Couldn't define flux_Ca");
    retval = -1;
  }
  if (VSfdefine(vdata_id_sis_level2_all_1day, "flux_Fe", DFNT_FLOAT32, (NUMBER_OF_ENERGY_BANDS) )) {
    print_sis_level2_all_1day_error("init_cr_sis_level2_all_1day -> VSfdefine: Couldn't define flux_Fe");
    retval = -1;
  }
  if (VSfdefine(vdata_id_sis_level2_all_1day, "flux_Ni", DFNT_FLOAT32, (NUMBER_OF_ENERGY_BANDS) )) {
    print_sis_level2_all_1day_error("init_cr_sis_level2_all_1day -> VSfdefine: Couldn't define flux_Ni");
    retval = -1;
  }
  if (VSfdefine(vdata_id_sis_level2_all_1day, "cnt_He", DFNT_FLOAT32, (NUMBER_OF_ENERGY_BANDS) )) {
    print_sis_level2_all_1day_error("init_cr_sis_level2_all_1day -> VSfdefine: Couldn't define cnt_He");
    retval = -1;
  }
  if (VSfdefine(vdata_id_sis_level2_all_1day, "cnt_C", DFNT_FLOAT32, (NUMBER_OF_ENERGY_BANDS) )) {
    print_sis_level2_all_1day_error("init_cr_sis_level2_all_1day -> VSfdefine: Couldn't define cnt_C");
    retval = -1;
  }
  if (VSfdefine(vdata_id_sis_level2_all_1day, "cnt_N", DFNT_FLOAT32, (NUMBER_OF_ENERGY_BANDS) )) {
    print_sis_level2_all_1day_error("init_cr_sis_level2_all_1day -> VSfdefine: Couldn't define cnt_N");
    retval = -1;
  }
  if (VSfdefine(vdata_id_sis_level2_all_1day, "cnt_O", DFNT_FLOAT32, (NUMBER_OF_ENERGY_BANDS) )) {
    print_sis_level2_all_1day_error("init_cr_sis_level2_all_1day -> VSfdefine: Couldn't define cnt_O");
    retval = -1;
  }
  if (VSfdefine(vdata_id_sis_level2_all_1day, "cnt_Ne", DFNT_FLOAT32, (NUMBER_OF_ENERGY_BANDS) )) {
    print_sis_level2_all_1day_error("init_cr_sis_level2_all_1day -> VSfdefine: Couldn't define cnt_Ne");
    retval = -1;
  }
  if (VSfdefine(vdata_id_sis_level2_all_1day, "cnt_Na", DFNT_FLOAT32, (NUMBER_OF_ENERGY_BANDS) )) {
    print_sis_level2_all_1day_error("init_cr_sis_level2_all_1day -> VSfdefine: Couldn't define cnt_Na");
    retval = -1;
  }
  if (VSfdefine(vdata_id_sis_level2_all_1day, "cnt_Mg", DFNT_FLOAT32, (NUMBER_OF_ENERGY_BANDS) )) {
    print_sis_level2_all_1day_error("init_cr_sis_level2_all_1day -> VSfdefine: Couldn't define cnt_Mg");
    retval = -1;
  }
  if (VSfdefine(vdata_id_sis_level2_all_1day, "cnt_Al", DFNT_FLOAT32, (NUMBER_OF_ENERGY_BANDS) )) {
    print_sis_level2_all_1day_error("init_cr_sis_level2_all_1day -> VSfdefine: Couldn't define cnt_Al");
    retval = -1;
  }
  if (VSfdefine(vdata_id_sis_level2_all_1day, "cnt_Si", DFNT_FLOAT32, (NUMBER_OF_ENERGY_BANDS) )) {
    print_sis_level2_all_1day_error("init_cr_sis_level2_all_1day -> VSfdefine: Couldn't define cnt_Si");
    retval = -1;
  }
  if (VSfdefine(vdata_id_sis_level2_all_1day, "cnt_S", DFNT_FLOAT32, (NUMBER_OF_ENERGY_BANDS) )) {
    print_sis_level2_all_1day_error("init_cr_sis_level2_all_1day -> VSfdefine: Couldn't define cnt_S");
    retval = -1;
  }
  if (VSfdefine(vdata_id_sis_level2_all_1day, "cnt_Ar", DFNT_FLOAT32, (NUMBER_OF_ENERGY_BANDS) )) {
    print_sis_level2_all_1day_error("init_cr_sis_level2_all_1day -> VSfdefine: Couldn't define cnt_Ar");
    retval = -1;
  }
  if (VSfdefine(vdata_id_sis_level2_all_1day, "cnt_Ca", DFNT_FLOAT32, (NUMBER_OF_ENERGY_BANDS) )) {
    print_sis_level2_all_1day_error("init_cr_sis_level2_all_1day -> VSfdefine: Couldn't define cnt_Ca");
    retval = -1;
  }
  if (VSfdefine(vdata_id_sis_level2_all_1day, "cnt_Fe", DFNT_FLOAT32, (NUMBER_OF_ENERGY_BANDS) )) {
    print_sis_level2_all_1day_error("init_cr_sis_level2_all_1day -> VSfdefine: Couldn't define cnt_Fe");
    retval = -1;
  }
  if (VSfdefine(vdata_id_sis_level2_all_1day, "cnt_Ni", DFNT_FLOAT32, (NUMBER_OF_ENERGY_BANDS) )) {
    print_sis_level2_all_1day_error("init_cr_sis_level2_all_1day -> VSfdefine: Couldn't define cnt_Ni");
    retval = -1;
  }
  if (VSfdefine(vdata_id_sis_level2_all_1day, "up_time_fraction", DFNT_FLOAT32, (1) )) {
    print_sis_level2_all_1day_error("init_cr_sis_level2_all_1day -> VSfdefine: Couldn't define up_time_fraction");
    retval = -1;
  }
  if (VSfdefine(vdata_id_sis_level2_all_1day, "solar_activity_flag", DFNT_INT32, (1) )) {
    print_sis_level2_all_1day_error("init_cr_sis_level2_all_1day -> VSfdefine: Couldn't define solar_activity_flag");
    retval = -1;
  }

  if (VSsetfields(vdata_id_sis_level2_all_1day,"year, day, hr, min, sec, fp_year, fp_doy, ACEepoch, flux_He, flux_C, flux_N, flux_O, flux_Ne, flux_Na, flux_Mg, flux_Al, flux_Si, flux_S, flux_Ar, flux_Ca, flux_Fe, flux_Ni, cnt_He, cnt_C, cnt_N, cnt_O, cnt_Ne, cnt_Na, cnt_Mg, cnt_Al, cnt_Si, cnt_S, cnt_Ar, cnt_Ca, cnt_Fe, cnt_Ni, up_time_fraction, solar_activity_flag")){
    print_sis_level2_all_1day_error("init_cr_sis_level2_all_1day -> VSsetfields: Couldn't set fields");
    retval = -1;
  }

  return(retval);
}

/* Included for backwards compatibility */

int32 init_wr_sis_level2_all_1day(int32 hdf_fp, int32 sd_id, int32 an_id, char *classname)
{ return( init_cr_sis_level2_all_1day(hdf_fp, sd_id, an_id, classname) ); }

/******---- write function ----******/

int32 write_sis_level2_all_1day(struct SIS_data_1day SIS_data_1day_struc, int32 recnum)
{
  int32 retval = 0;
  uint8 *odata;

void print_sis_level2_all_1day_error();
void pack_sis_level2_all_1day();

  odata = (uint8 *) malloc(sizeof(struct SIS_data_1day));
  pack_sis_level2_all_1day(odata, &SIS_data_1day_struc);

  if(recnum!=-1) {
	if(VSseek(vdata_id_sis_level2_all_1day, recnum)==-1) {
		print_sis_level2_all_1day_error("write_sis_level2_all_1day -> VSseek: error.");
		retval = -1;
	}
  }
  if(VSwrite(vdata_id_sis_level2_all_1day, (uint8 *)odata, 1, FULL_INTERLACE) == -1)
    print_sis_level2_all_1day_error("write_sis_level2_all_1day -> VSwrite: Couldn't write data.");

  memset(&SIS_data_1day_struc, 0, sizeof(struct SIS_data_1day));
  free(odata);
  return(retval);
}

/*----   close write function    ----*/

void close_wr_sis_level2_all_1day()
{
  VSdetach(vdata_id_sis_level2_all_1day);
  Vdetach(vgrp_id_sis_level2_all_1day);
}

/*----     init access function    ----*/

int32 init_acc_sis_level2_all_1day(int32 hdf_fp, int32 sd_id, char *access_mode)
{
  int32 vdata_ref;
  int32 num_rec;

  void print_sis_level2_all_1day_error();


  if ((vdata_ref = VSfind(hdf_fp, "SIS_data_1day")) <= 0 ) {
    print_sis_level2_all_1day_error("init_acc_sis_level2_all_1day -> VSfind: Found no vdata of specified type.");
    return(0);
  }
  if ((vdata_id_sis_level2_all_1day = VSattach(hdf_fp, vdata_ref, access_mode)) ==FAIL) {
    print_sis_level2_all_1day_error("init_acc_sis_level2_all_1day -> VSattach: Couldn't attach to hdf file.");
    return(-1);
  }

  VSinquire(vdata_id_sis_level2_all_1day, &num_rec, NULL, NULL, NULL, NULL);
  if (num_rec == 0) { return(0); }


  if (VSsetfields(vdata_id_sis_level2_all_1day,"year, day, hr, min, sec, fp_year, fp_doy, ACEepoch, flux_He, flux_C, flux_N, flux_O, flux_Ne, flux_Na, flux_Mg, flux_Al, flux_Si, flux_S, flux_Ar, flux_Ca, flux_Fe, flux_Ni, cnt_He, cnt_C, cnt_N, cnt_O, cnt_Ne, cnt_Na, cnt_Mg, cnt_Al, cnt_Si, cnt_S, cnt_Ar, cnt_Ca, cnt_Fe, cnt_Ni, up_time_fraction, solar_activity_flag")) {
      print_sis_level2_all_1day_error("init_acc_sis_level2_all_1day -> VSsetfields: Unable to set fields.");
      return(-1);
  }
  return(num_rec);
}

/* Included for backwards compatability */

int32 init_rd_sis_level2_all_1day(int32 hdf_fp, int32 sd_id, char *access_mode)
{ return ( init_acc_sis_level2_all_1day(hdf_fp, sd_id, access_mode) ); }

/******---- read function ----******/

int32 read_sis_level2_all_1day(struct SIS_data_1day *SIS_data_1day_struc, int32 recnum_rd)
{
int32 maxrec;
static int32 last_recnum = -1;
int32 retval = 0;
uint8 *odata;

void print_sis_level2_all_1day_error();
void unpack_sis_level2_all_1day();

  if(recnum_rd==-1) recnum_rd=last_recnum+1;

  odata = (uint8 *) malloc(sizeof(struct SIS_data_1day));
  VSinquire(vdata_id_sis_level2_all_1day, &maxrec, NULL, NULL, NULL, NULL);
  if (recnum_rd >= maxrec) return(-1);
  if (recnum_rd != last_recnum+1)
      if (VSseek(vdata_id_sis_level2_all_1day, recnum_rd)==FAIL) {
          print_sis_level2_all_1day_error("read_sis_level2_all_1day -> VSseek unsuccessful");
          retval = -1;
    }
  last_recnum = recnum_rd;

  if(VSread(vdata_id_sis_level2_all_1day, (uint8 *)odata, 1, FULL_INTERLACE) ==FAIL) {
    print_sis_level2_all_1day_error("read_sis_level2_all_1day -> VSread: Couldn't read data.");
    retval = -1;
  }
  unpack_sis_level2_all_1day(odata, SIS_data_1day_struc);
  free(odata);
  return(retval);
}

/*----   close read function    ----*/

void close_rd_sis_level2_all_1day()
{
  VSdetach(vdata_id_sis_level2_all_1day);
}

/*----  Read V group description, function    ----*/
void rd_Vgrp_desc_sis_level2_all_1day(int32 hdf_fp, int32 an_id)
{
  int32 ann_id_r;
  int32 num_ann;
  int32 *ann_list;
  int32 vgrp_ref_r;

void print_sis_level2_all_1day_error();

  /*      Get the Vgroup reference     */
  if ((vgrp_ref_r = Vfind(hdf_fp, "VG_SIS_data_1day" )) ==FAIL)
    print_sis_level2_all_1day_error("rd_Vgrp_sis_level2_all_1day -> Vfind: Couldn't get Vgrp reference.");

  if ((num_ann = ANnumann(an_id, AN_DATA_DESC, DFTAG_VG, vgrp_ref_r)) ==FAIL)
    print_sis_level2_all_1day_error("rd_Vgrp_sis_level2_all_1day -> ANnumann: Couldn't get number of annotations.");

    ann_list = HDmalloc(num_ann * sizeof(int32));
  if ((num_ann = ANannlist(an_id, AN_DATA_DESC, DFTAG_VG, vgrp_ref_r, ann_list)) ==FAIL)
    print_sis_level2_all_1day_error("rd_Vgrp_sis_level2_all_1day -> ANannlist: Couldn't");

  if ((ann_id_r = ANselect(an_id, (num_ann-1), AN_DATA_DESC)) ==FAIL)
    print_sis_level2_all_1day_error("rd_Vgrp_sis_level2_all_1day -> ANselect: Couldn't");

  if (ANreadann(ann_id_r, Vgrp_descrp_SIS_data_1day, HDstrlen(Vgrp_descrp_SIS_data_1day)) ==FAIL)
    print_sis_level2_all_1day_error("rd_Vgrp_sis_level2_all_1day -> ANreadann: Couldn't");

  printf("AN: %s\n", Vgrp_descrp_SIS_data_1day);
  ANendaccess(ann_id_r);
  ANend(an_id);
}

/*----   error function    ----*/

void print_sis_level2_all_1day_error(int8 *mess)
{
  fprintf(stderr,"\nERROR in  hdf_sis_level2_all_1day.c -> %s\n", mess);
  HEprint(stderr, 0);
}

/*----   pack function    ----*/

void pack_sis_level2_all_1day(uint8 *data, struct SIS_data_1day *SIS_data_1day_ptr)
{
int32 ptr=0;

   memcpy(data+ptr, &SIS_data_1day_ptr->year, ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(data+ptr, &SIS_data_1day_ptr->day, ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(data+ptr, &SIS_data_1day_ptr->hr, ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(data+ptr, &SIS_data_1day_ptr->min, ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(data+ptr, &SIS_data_1day_ptr->sec, ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(data+ptr, &SIS_data_1day_ptr->fp_year, ((8)*(1)) );
   ptr+= ((8)*(1));
   memcpy(data+ptr, &SIS_data_1day_ptr->fp_doy, ((8)*(1)) );
   ptr+= ((8)*(1));
   memcpy(data+ptr, &SIS_data_1day_ptr->ACEepoch, ((8)*(1)) );
   ptr+= ((8)*(1));
   memcpy(data+ptr, &SIS_data_1day_ptr->flux_He[0], ((4)*(NUMBER_OF_ENERGY_BANDS)) );
   ptr+= ((4)*(NUMBER_OF_ENERGY_BANDS));
   memcpy(data+ptr, &SIS_data_1day_ptr->flux_C[0], ((4)*(NUMBER_OF_ENERGY_BANDS)) );
   ptr+= ((4)*(NUMBER_OF_ENERGY_BANDS));
   memcpy(data+ptr, &SIS_data_1day_ptr->flux_N[0], ((4)*(NUMBER_OF_ENERGY_BANDS)) );
   ptr+= ((4)*(NUMBER_OF_ENERGY_BANDS));
   memcpy(data+ptr, &SIS_data_1day_ptr->flux_O[0], ((4)*(NUMBER_OF_ENERGY_BANDS)) );
   ptr+= ((4)*(NUMBER_OF_ENERGY_BANDS));
   memcpy(data+ptr, &SIS_data_1day_ptr->flux_Ne[0], ((4)*(NUMBER_OF_ENERGY_BANDS)) );
   ptr+= ((4)*(NUMBER_OF_ENERGY_BANDS));
   memcpy(data+ptr, &SIS_data_1day_ptr->flux_Na[0], ((4)*(NUMBER_OF_ENERGY_BANDS)) );
   ptr+= ((4)*(NUMBER_OF_ENERGY_BANDS));
   memcpy(data+ptr, &SIS_data_1day_ptr->flux_Mg[0], ((4)*(NUMBER_OF_ENERGY_BANDS)) );
   ptr+= ((4)*(NUMBER_OF_ENERGY_BANDS));
   memcpy(data+ptr, &SIS_data_1day_ptr->flux_Al[0], ((4)*(NUMBER_OF_ENERGY_BANDS)) );
   ptr+= ((4)*(NUMBER_OF_ENERGY_BANDS));
   memcpy(data+ptr, &SIS_data_1day_ptr->flux_Si[0], ((4)*(NUMBER_OF_ENERGY_BANDS)) );
   ptr+= ((4)*(NUMBER_OF_ENERGY_BANDS));
   memcpy(data+ptr, &SIS_data_1day_ptr->flux_S[0], ((4)*(NUMBER_OF_ENERGY_BANDS)) );
   ptr+= ((4)*(NUMBER_OF_ENERGY_BANDS));
   memcpy(data+ptr, &SIS_data_1day_ptr->flux_Ar[0], ((4)*(NUMBER_OF_ENERGY_BANDS)) );
   ptr+= ((4)*(NUMBER_OF_ENERGY_BANDS));
   memcpy(data+ptr, &SIS_data_1day_ptr->flux_Ca[0], ((4)*(NUMBER_OF_ENERGY_BANDS)) );
   ptr+= ((4)*(NUMBER_OF_ENERGY_BANDS));
   memcpy(data+ptr, &SIS_data_1day_ptr->flux_Fe[0], ((4)*(NUMBER_OF_ENERGY_BANDS)) );
   ptr+= ((4)*(NUMBER_OF_ENERGY_BANDS));
   memcpy(data+ptr, &SIS_data_1day_ptr->flux_Ni[0], ((4)*(NUMBER_OF_ENERGY_BANDS)) );
   ptr+= ((4)*(NUMBER_OF_ENERGY_BANDS));
   memcpy(data+ptr, &SIS_data_1day_ptr->cnt_He[0], ((4)*(NUMBER_OF_ENERGY_BANDS)) );
   ptr+= ((4)*(NUMBER_OF_ENERGY_BANDS));
   memcpy(data+ptr, &SIS_data_1day_ptr->cnt_C[0], ((4)*(NUMBER_OF_ENERGY_BANDS)) );
   ptr+= ((4)*(NUMBER_OF_ENERGY_BANDS));
   memcpy(data+ptr, &SIS_data_1day_ptr->cnt_N[0], ((4)*(NUMBER_OF_ENERGY_BANDS)) );
   ptr+= ((4)*(NUMBER_OF_ENERGY_BANDS));
   memcpy(data+ptr, &SIS_data_1day_ptr->cnt_O[0], ((4)*(NUMBER_OF_ENERGY_BANDS)) );
   ptr+= ((4)*(NUMBER_OF_ENERGY_BANDS));
   memcpy(data+ptr, &SIS_data_1day_ptr->cnt_Ne[0], ((4)*(NUMBER_OF_ENERGY_BANDS)) );
   ptr+= ((4)*(NUMBER_OF_ENERGY_BANDS));
   memcpy(data+ptr, &SIS_data_1day_ptr->cnt_Na[0], ((4)*(NUMBER_OF_ENERGY_BANDS)) );
   ptr+= ((4)*(NUMBER_OF_ENERGY_BANDS));
   memcpy(data+ptr, &SIS_data_1day_ptr->cnt_Mg[0], ((4)*(NUMBER_OF_ENERGY_BANDS)) );
   ptr+= ((4)*(NUMBER_OF_ENERGY_BANDS));
   memcpy(data+ptr, &SIS_data_1day_ptr->cnt_Al[0], ((4)*(NUMBER_OF_ENERGY_BANDS)) );
   ptr+= ((4)*(NUMBER_OF_ENERGY_BANDS));
   memcpy(data+ptr, &SIS_data_1day_ptr->cnt_Si[0], ((4)*(NUMBER_OF_ENERGY_BANDS)) );
   ptr+= ((4)*(NUMBER_OF_ENERGY_BANDS));
   memcpy(data+ptr, &SIS_data_1day_ptr->cnt_S[0], ((4)*(NUMBER_OF_ENERGY_BANDS)) );
   ptr+= ((4)*(NUMBER_OF_ENERGY_BANDS));
   memcpy(data+ptr, &SIS_data_1day_ptr->cnt_Ar[0], ((4)*(NUMBER_OF_ENERGY_BANDS)) );
   ptr+= ((4)*(NUMBER_OF_ENERGY_BANDS));
   memcpy(data+ptr, &SIS_data_1day_ptr->cnt_Ca[0], ((4)*(NUMBER_OF_ENERGY_BANDS)) );
   ptr+= ((4)*(NUMBER_OF_ENERGY_BANDS));
   memcpy(data+ptr, &SIS_data_1day_ptr->cnt_Fe[0], ((4)*(NUMBER_OF_ENERGY_BANDS)) );
   ptr+= ((4)*(NUMBER_OF_ENERGY_BANDS));
   memcpy(data+ptr, &SIS_data_1day_ptr->cnt_Ni[0], ((4)*(NUMBER_OF_ENERGY_BANDS)) );
   ptr+= ((4)*(NUMBER_OF_ENERGY_BANDS));
   memcpy(data+ptr, &SIS_data_1day_ptr->up_time_fraction, ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(data+ptr, &SIS_data_1day_ptr->solar_activity_flag, ((4)*(1)) );
   ptr+= ((4)*(1));
}

/*----   unpack function    ----*/

void unpack_sis_level2_all_1day(uint8 *data, struct SIS_data_1day *SIS_data_1day_ptr)
{
int32 ptr=0;

   memcpy(&SIS_data_1day_ptr->year, data+ptr,  ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(&SIS_data_1day_ptr->day, data+ptr,  ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(&SIS_data_1day_ptr->hr, data+ptr,  ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(&SIS_data_1day_ptr->min, data+ptr,  ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(&SIS_data_1day_ptr->sec, data+ptr,  ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(&SIS_data_1day_ptr->fp_year, data+ptr,  ((8)*(1)) );
   ptr+= ((8)*(1));
   memcpy(&SIS_data_1day_ptr->fp_doy, data+ptr,  ((8)*(1)) );
   ptr+= ((8)*(1));
   memcpy(&SIS_data_1day_ptr->ACEepoch, data+ptr,  ((8)*(1)) );
   ptr+= ((8)*(1));
   memcpy(&SIS_data_1day_ptr->flux_He[0], data+ptr,  ((4)*(NUMBER_OF_ENERGY_BANDS)) );
   ptr+= ((4)*(NUMBER_OF_ENERGY_BANDS));
   memcpy(&SIS_data_1day_ptr->flux_C[0], data+ptr,  ((4)*(NUMBER_OF_ENERGY_BANDS)) );
   ptr+= ((4)*(NUMBER_OF_ENERGY_BANDS));
   memcpy(&SIS_data_1day_ptr->flux_N[0], data+ptr,  ((4)*(NUMBER_OF_ENERGY_BANDS)) );
   ptr+= ((4)*(NUMBER_OF_ENERGY_BANDS));
   memcpy(&SIS_data_1day_ptr->flux_O[0], data+ptr,  ((4)*(NUMBER_OF_ENERGY_BANDS)) );
   ptr+= ((4)*(NUMBER_OF_ENERGY_BANDS));
   memcpy(&SIS_data_1day_ptr->flux_Ne[0], data+ptr,  ((4)*(NUMBER_OF_ENERGY_BANDS)) );
   ptr+= ((4)*(NUMBER_OF_ENERGY_BANDS));
   memcpy(&SIS_data_1day_ptr->flux_Na[0], data+ptr,  ((4)*(NUMBER_OF_ENERGY_BANDS)) );
   ptr+= ((4)*(NUMBER_OF_ENERGY_BANDS));
   memcpy(&SIS_data_1day_ptr->flux_Mg[0], data+ptr,  ((4)*(NUMBER_OF_ENERGY_BANDS)) );
   ptr+= ((4)*(NUMBER_OF_ENERGY_BANDS));
   memcpy(&SIS_data_1day_ptr->flux_Al[0], data+ptr,  ((4)*(NUMBER_OF_ENERGY_BANDS)) );
   ptr+= ((4)*(NUMBER_OF_ENERGY_BANDS));
   memcpy(&SIS_data_1day_ptr->flux_Si[0], data+ptr,  ((4)*(NUMBER_OF_ENERGY_BANDS)) );
   ptr+= ((4)*(NUMBER_OF_ENERGY_BANDS));
   memcpy(&SIS_data_1day_ptr->flux_S[0], data+ptr,  ((4)*(NUMBER_OF_ENERGY_BANDS)) );
   ptr+= ((4)*(NUMBER_OF_ENERGY_BANDS));
   memcpy(&SIS_data_1day_ptr->flux_Ar[0], data+ptr,  ((4)*(NUMBER_OF_ENERGY_BANDS)) );
   ptr+= ((4)*(NUMBER_OF_ENERGY_BANDS));
   memcpy(&SIS_data_1day_ptr->flux_Ca[0], data+ptr,  ((4)*(NUMBER_OF_ENERGY_BANDS)) );
   ptr+= ((4)*(NUMBER_OF_ENERGY_BANDS));
   memcpy(&SIS_data_1day_ptr->flux_Fe[0], data+ptr,  ((4)*(NUMBER_OF_ENERGY_BANDS)) );
   ptr+= ((4)*(NUMBER_OF_ENERGY_BANDS));
   memcpy(&SIS_data_1day_ptr->flux_Ni[0], data+ptr,  ((4)*(NUMBER_OF_ENERGY_BANDS)) );
   ptr+= ((4)*(NUMBER_OF_ENERGY_BANDS));
   memcpy(&SIS_data_1day_ptr->cnt_He[0], data+ptr,  ((4)*(NUMBER_OF_ENERGY_BANDS)) );
   ptr+= ((4)*(NUMBER_OF_ENERGY_BANDS));
   memcpy(&SIS_data_1day_ptr->cnt_C[0], data+ptr,  ((4)*(NUMBER_OF_ENERGY_BANDS)) );
   ptr+= ((4)*(NUMBER_OF_ENERGY_BANDS));
   memcpy(&SIS_data_1day_ptr->cnt_N[0], data+ptr,  ((4)*(NUMBER_OF_ENERGY_BANDS)) );
   ptr+= ((4)*(NUMBER_OF_ENERGY_BANDS));
   memcpy(&SIS_data_1day_ptr->cnt_O[0], data+ptr,  ((4)*(NUMBER_OF_ENERGY_BANDS)) );
   ptr+= ((4)*(NUMBER_OF_ENERGY_BANDS));
   memcpy(&SIS_data_1day_ptr->cnt_Ne[0], data+ptr,  ((4)*(NUMBER_OF_ENERGY_BANDS)) );
   ptr+= ((4)*(NUMBER_OF_ENERGY_BANDS));
   memcpy(&SIS_data_1day_ptr->cnt_Na[0], data+ptr,  ((4)*(NUMBER_OF_ENERGY_BANDS)) );
   ptr+= ((4)*(NUMBER_OF_ENERGY_BANDS));
   memcpy(&SIS_data_1day_ptr->cnt_Mg[0], data+ptr,  ((4)*(NUMBER_OF_ENERGY_BANDS)) );
   ptr+= ((4)*(NUMBER_OF_ENERGY_BANDS));
   memcpy(&SIS_data_1day_ptr->cnt_Al[0], data+ptr,  ((4)*(NUMBER_OF_ENERGY_BANDS)) );
   ptr+= ((4)*(NUMBER_OF_ENERGY_BANDS));
   memcpy(&SIS_data_1day_ptr->cnt_Si[0], data+ptr,  ((4)*(NUMBER_OF_ENERGY_BANDS)) );
   ptr+= ((4)*(NUMBER_OF_ENERGY_BANDS));
   memcpy(&SIS_data_1day_ptr->cnt_S[0], data+ptr,  ((4)*(NUMBER_OF_ENERGY_BANDS)) );
   ptr+= ((4)*(NUMBER_OF_ENERGY_BANDS));
   memcpy(&SIS_data_1day_ptr->cnt_Ar[0], data+ptr,  ((4)*(NUMBER_OF_ENERGY_BANDS)) );
   ptr+= ((4)*(NUMBER_OF_ENERGY_BANDS));
   memcpy(&SIS_data_1day_ptr->cnt_Ca[0], data+ptr,  ((4)*(NUMBER_OF_ENERGY_BANDS)) );
   ptr+= ((4)*(NUMBER_OF_ENERGY_BANDS));
   memcpy(&SIS_data_1day_ptr->cnt_Fe[0], data+ptr,  ((4)*(NUMBER_OF_ENERGY_BANDS)) );
   ptr+= ((4)*(NUMBER_OF_ENERGY_BANDS));
   memcpy(&SIS_data_1day_ptr->cnt_Ni[0], data+ptr,  ((4)*(NUMBER_OF_ENERGY_BANDS)) );
   ptr+= ((4)*(NUMBER_OF_ENERGY_BANDS));
   memcpy(&SIS_data_1day_ptr->up_time_fraction, data+ptr,  ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(&SIS_data_1day_ptr->solar_activity_flag, data+ptr,  ((4)*(1)) );
   ptr+= ((4)*(1));
}
int32 get_vgrp_id_sis_level2_all_1day() {return(vgrp_id_sis_level2_all_1day);}

/*----   V group description function    ----*/

int32 wr_Vgrp_desc_sis_level2_all_1day(char *wr_strval)
{
  strcpy(wr_strval, "The file 'sis_level2_data_1day.h' is shown below, it was used to create the data in the Vgroup named 'VG_SIS_data_1day'.\n\n");
  strcat(wr_strval,"/* Id: sis_level2_data_1day.h,v 1.1 2000/08/02 00:50:30 asc Exp asc $ */\n");
  strcat(wr_strval,"\n");
  strcat(wr_strval,"#include \"hdfi.h\"\n");
  strcat(wr_strval,"#include \"sis_sizes.h\"\n");
  strcat(wr_strval,"\n");
  strcat(wr_strval,"struct SIS_data_1day {\n");
  strcat(wr_strval,"\n");
  strcat(wr_strval,"  /* UT time at the start of the periods */\n");
  strcat(wr_strval,"  int32   year;                         /* integer year */\n");
  strcat(wr_strval,"  int32   day;                          /* integer day of year */\n");
  strcat(wr_strval,"  int32   hr;                           /* hour of day */\n");
  strcat(wr_strval,"  int32   min;                          /* min of hour */\n");
  strcat(wr_strval,"  float32 sec;                          /* seconds */\n");
  strcat(wr_strval,"  float64 fp_year;                      /* floating point year */\n");
  strcat(wr_strval,"  float64 fp_doy;                       /* floating point Day of YearDOY */ \n");
  strcat(wr_strval,"  float64 ACEepoch;                     /* UT time in sec since 1/1/96 */\n");
  strcat(wr_strval,"\n");
  strcat(wr_strval,"  float32  flux_He[NUMBER_OF_ENERGY_BANDS];\n");
  strcat(wr_strval,"  float32  flux_C[NUMBER_OF_ENERGY_BANDS];\n");
  strcat(wr_strval,"  float32  flux_N[NUMBER_OF_ENERGY_BANDS];\n");
  strcat(wr_strval,"  float32  flux_O[NUMBER_OF_ENERGY_BANDS];\n");
  strcat(wr_strval,"  float32  flux_Ne[NUMBER_OF_ENERGY_BANDS];\n");
  strcat(wr_strval,"  float32  flux_Na[NUMBER_OF_ENERGY_BANDS];\n");
  strcat(wr_strval,"  float32  flux_Mg[NUMBER_OF_ENERGY_BANDS];\n");
  strcat(wr_strval,"  float32  flux_Al[NUMBER_OF_ENERGY_BANDS];\n");
  strcat(wr_strval,"  float32  flux_Si[NUMBER_OF_ENERGY_BANDS];\n");
  strcat(wr_strval,"  float32  flux_S[NUMBER_OF_ENERGY_BANDS];\n");
  strcat(wr_strval,"  float32  flux_Ar[NUMBER_OF_ENERGY_BANDS];\n");
  strcat(wr_strval,"  float32  flux_Ca[NUMBER_OF_ENERGY_BANDS];\n");
  strcat(wr_strval,"  float32  flux_Fe[NUMBER_OF_ENERGY_BANDS];\n");
  strcat(wr_strval,"  float32  flux_Ni[NUMBER_OF_ENERGY_BANDS];\n");
  strcat(wr_strval,"\n");
  strcat(wr_strval,"  float32  cnt_He[NUMBER_OF_ENERGY_BANDS];\n");
  strcat(wr_strval,"  float32  cnt_C[NUMBER_OF_ENERGY_BANDS];\n");
  strcat(wr_strval,"  float32  cnt_N[NUMBER_OF_ENERGY_BANDS];\n");
  strcat(wr_strval,"  float32  cnt_O[NUMBER_OF_ENERGY_BANDS];\n");
  strcat(wr_strval,"  float32  cnt_Ne[NUMBER_OF_ENERGY_BANDS];\n");
  strcat(wr_strval,"  float32  cnt_Na[NUMBER_OF_ENERGY_BANDS];\n");
  strcat(wr_strval,"  float32  cnt_Mg[NUMBER_OF_ENERGY_BANDS];\n");
  strcat(wr_strval,"  float32  cnt_Al[NUMBER_OF_ENERGY_BANDS];\n");
  strcat(wr_strval,"  float32  cnt_Si[NUMBER_OF_ENERGY_BANDS];\n");
  strcat(wr_strval,"  float32  cnt_S[NUMBER_OF_ENERGY_BANDS];\n");
  strcat(wr_strval,"  float32  cnt_Ar[NUMBER_OF_ENERGY_BANDS];\n");
  strcat(wr_strval,"  float32  cnt_Ca[NUMBER_OF_ENERGY_BANDS];\n");
  strcat(wr_strval,"  float32  cnt_Fe[NUMBER_OF_ENERGY_BANDS];\n");
  strcat(wr_strval,"  float32  cnt_Ni[NUMBER_OF_ENERGY_BANDS];\n");
  strcat(wr_strval,"\n");
  strcat(wr_strval,"  float32 up_time_fraction;        \n");
  strcat(wr_strval,"  int32   solar_activity_flag;  /* = 0 less than threshold    */\n");
  strcat(wr_strval,"                                /* = 1 greater than threshold */\n");
  strcat(wr_strval,"\n");
  strcat(wr_strval,"};\n");
  return(0);
}
