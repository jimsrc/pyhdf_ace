/* The RCS version of hdfgen.pl used to create this file is: */
/* $Id: hdfgen.pl,v 1.49 1999/11/04 17:17:13 asc Exp  */

/* The include file used to create this file is: */
/* $Id: sepica_level2_data_Bartels.h,v 1.2 2001/07/03 00:05:54 steves Exp  */

#include "sepica_level2_data_Bartels.h"
#include "df.h"

int32 vgrp_id_sepica_level2_data_Bartels;
static int32 vdata_id_sepica_level2_data_Bartels;

  /* 3889 is the size of sepica_level2_data_Bartels.h + 1 added line */
char Vgrp_descrp_SEPICA_data_Bartels[3889];

/****----  init create function  ----****/

int32 init_cr_sepica_level2_data_Bartels(int32 hdf_fp, int32 sd_id, int32 an_id, char *classname)
{
  int32 retval=0;
  int32 vgrp_ref_w;
  int32 ann_id_w;
  int32 wr_Vgrp_desc_sepica_level2_data_Bartels();

  void print_sepica_level2_data_Bartels_error();

  /*         Setup a Vgroup         */
  if ((vgrp_id_sepica_level2_data_Bartels = Vattach(hdf_fp, -1, "w"))==FAIL) {
    print_sepica_level2_data_Bartels_error("init_cr_sepica_level2_data_Bartels -> Vattach: Couldn't create Vgroup");
    retval = -1;
  }
  Vsetname(vgrp_id_sepica_level2_data_Bartels, "VG_SEPICA_data_Bartels"); 
  Vsetclass(vgrp_id_sepica_level2_data_Bartels, "VG_SEPICA_LEVEL2_DATA_BARTELS");


  /*      Get the Vgroup reference     */
  if ((vgrp_ref_w = Vfind(hdf_fp, "VG_SEPICA_data_Bartels" )) ==FAIL) {
    print_sepica_level2_data_Bartels_error("init_cr_sepica_level2_data_Bartels -> Vfind: Couldn't get Vgrp reference");
    retval = -1;
  }
  /*      Add a description to the Vgroup      */
  wr_Vgrp_desc_sepica_level2_data_Bartels(Vgrp_descrp_SEPICA_data_Bartels);

  if ((ann_id_w = ANcreate(an_id, DFTAG_VG, vgrp_ref_w, AN_DATA_DESC)) ==FAIL) {
    print_sepica_level2_data_Bartels_error("init_cr_sepica_level2_data_Bartels -> ANcreate: Can't create Vgrp description");
    retval = -1;
  }
  if ((ANwriteann(ann_id_w, Vgrp_descrp_SEPICA_data_Bartels, sizeof(Vgrp_descrp_SEPICA_data_Bartels))) ==FAIL) {
    print_sepica_level2_data_Bartels_error("init_cr_sepica_level2_data_Bartels -> ANwriteann: Can't write Vgrp description");
    retval = -1;
  }
  ANendaccess(ann_id_w);

  /*        Setup a Vdata        */
  if ((vdata_id_sepica_level2_data_Bartels = VSattach(hdf_fp, -1, "w")) ==FAIL) {
    print_sepica_level2_data_Bartels_error("init_cr_sepica_level2_data_Bartels -> VSattach: Couldn't attach to Vdata");
    retval = -1;
  }
  VSsetname(vdata_id_sepica_level2_data_Bartels, "SEPICA_data_Bartels");
  VSsetclass(vdata_id_sepica_level2_data_Bartels, classname);

  /*       Insert the Vdata into the Vgroup       */
  if ((Vinsert(vgrp_id_sepica_level2_data_Bartels, vdata_id_sepica_level2_data_Bartels)) ==FAIL) {
    print_sepica_level2_data_Bartels_error("init_cr_sepica_level2_data_Bartels -> Vinsert: Couldn't insert Vdata into Vgroup");
    retval = -1;
  }

  /*    Define the fields in the Vdata    */
  if (VSfdefine(vdata_id_sepica_level2_data_Bartels, "year", DFNT_INT32, (1) )) {
    print_sepica_level2_data_Bartels_error("init_cr_sepica_level2_data_Bartels -> VSfdefine: Couldn't define year");
    retval = -1;
  }
  if (VSfdefine(vdata_id_sepica_level2_data_Bartels, "day", DFNT_INT32, (1) )) {
    print_sepica_level2_data_Bartels_error("init_cr_sepica_level2_data_Bartels -> VSfdefine: Couldn't define day");
    retval = -1;
  }
  if (VSfdefine(vdata_id_sepica_level2_data_Bartels, "hr", DFNT_INT32, (1) )) {
    print_sepica_level2_data_Bartels_error("init_cr_sepica_level2_data_Bartels -> VSfdefine: Couldn't define hr");
    retval = -1;
  }
  if (VSfdefine(vdata_id_sepica_level2_data_Bartels, "min", DFNT_INT32, (1) )) {
    print_sepica_level2_data_Bartels_error("init_cr_sepica_level2_data_Bartels -> VSfdefine: Couldn't define min");
    retval = -1;
  }
  if (VSfdefine(vdata_id_sepica_level2_data_Bartels, "sec", DFNT_FLOAT32, (1) )) {
    print_sepica_level2_data_Bartels_error("init_cr_sepica_level2_data_Bartels -> VSfdefine: Couldn't define sec");
    retval = -1;
  }
  if (VSfdefine(vdata_id_sepica_level2_data_Bartels, "fp_year", DFNT_FLOAT64, (1) )) {
    print_sepica_level2_data_Bartels_error("init_cr_sepica_level2_data_Bartels -> VSfdefine: Couldn't define fp_year");
    retval = -1;
  }
  if (VSfdefine(vdata_id_sepica_level2_data_Bartels, "fp_doy", DFNT_FLOAT64, (1) )) {
    print_sepica_level2_data_Bartels_error("init_cr_sepica_level2_data_Bartels -> VSfdefine: Couldn't define fp_doy");
    retval = -1;
  }
  if (VSfdefine(vdata_id_sepica_level2_data_Bartels, "ACEepoch", DFNT_FLOAT64, (1) )) {
    print_sepica_level2_data_Bartels_error("init_cr_sepica_level2_data_Bartels -> VSfdefine: Couldn't define ACEepoch");
    retval = -1;
  }
  if (VSfdefine(vdata_id_sepica_level2_data_Bartels, "H1", DFNT_FLOAT32, (1) )) {
    print_sepica_level2_data_Bartels_error("init_cr_sepica_level2_data_Bartels -> VSfdefine: Couldn't define H1");
    retval = -1;
  }
  if (VSfdefine(vdata_id_sepica_level2_data_Bartels, "H2", DFNT_FLOAT32, (1) )) {
    print_sepica_level2_data_Bartels_error("init_cr_sepica_level2_data_Bartels -> VSfdefine: Couldn't define H2");
    retval = -1;
  }
  if (VSfdefine(vdata_id_sepica_level2_data_Bartels, "H3", DFNT_FLOAT32, (1) )) {
    print_sepica_level2_data_Bartels_error("init_cr_sepica_level2_data_Bartels -> VSfdefine: Couldn't define H3");
    retval = -1;
  }
  if (VSfdefine(vdata_id_sepica_level2_data_Bartels, "He1", DFNT_FLOAT32, (1) )) {
    print_sepica_level2_data_Bartels_error("init_cr_sepica_level2_data_Bartels -> VSfdefine: Couldn't define He1");
    retval = -1;
  }
  if (VSfdefine(vdata_id_sepica_level2_data_Bartels, "He2", DFNT_FLOAT32, (1) )) {
    print_sepica_level2_data_Bartels_error("init_cr_sepica_level2_data_Bartels -> VSfdefine: Couldn't define He2");
    retval = -1;
  }
  if (VSfdefine(vdata_id_sepica_level2_data_Bartels, "He3", DFNT_FLOAT32, (1) )) {
    print_sepica_level2_data_Bartels_error("init_cr_sepica_level2_data_Bartels -> VSfdefine: Couldn't define He3");
    retval = -1;
  }
  if (VSfdefine(vdata_id_sepica_level2_data_Bartels, "He4cal", DFNT_FLOAT32, (1) )) {
    print_sepica_level2_data_Bartels_error("init_cr_sepica_level2_data_Bartels -> VSfdefine: Couldn't define He4cal");
    retval = -1;
  }
  if (VSfdefine(vdata_id_sepica_level2_data_Bartels, "He5", DFNT_FLOAT32, (1) )) {
    print_sepica_level2_data_Bartels_error("init_cr_sepica_level2_data_Bartels -> VSfdefine: Couldn't define He5");
    retval = -1;
  }
  if (VSfdefine(vdata_id_sepica_level2_data_Bartels, "He6", DFNT_FLOAT32, (1) )) {
    print_sepica_level2_data_Bartels_error("init_cr_sepica_level2_data_Bartels -> VSfdefine: Couldn't define He6");
    retval = -1;
  }
  if (VSfdefine(vdata_id_sepica_level2_data_Bartels, "He7", DFNT_FLOAT32, (1) )) {
    print_sepica_level2_data_Bartels_error("init_cr_sepica_level2_data_Bartels -> VSfdefine: Couldn't define He7");
    retval = -1;
  }
  if (VSfdefine(vdata_id_sepica_level2_data_Bartels, "He8", DFNT_FLOAT32, (1) )) {
    print_sepica_level2_data_Bartels_error("init_cr_sepica_level2_data_Bartels -> VSfdefine: Couldn't define He8");
    retval = -1;
  }
  if (VSfdefine(vdata_id_sepica_level2_data_Bartels, "HeCAck", DFNT_FLOAT32, (1) )) {
    print_sepica_level2_data_Bartels_error("init_cr_sepica_level2_data_Bartels -> VSfdefine: Couldn't define HeCAck");
    retval = -1;
  }
  if (VSfdefine(vdata_id_sepica_level2_data_Bartels, "ClowE", DFNT_FLOAT32, (1) )) {
    print_sepica_level2_data_Bartels_error("init_cr_sepica_level2_data_Bartels -> VSfdefine: Couldn't define ClowE");
    retval = -1;
  }
  if (VSfdefine(vdata_id_sepica_level2_data_Bartels, "C1", DFNT_FLOAT32, (1) )) {
    print_sepica_level2_data_Bartels_error("init_cr_sepica_level2_data_Bartels -> VSfdefine: Couldn't define C1");
    retval = -1;
  }
  if (VSfdefine(vdata_id_sepica_level2_data_Bartels, "C2", DFNT_FLOAT32, (1) )) {
    print_sepica_level2_data_Bartels_error("init_cr_sepica_level2_data_Bartels -> VSfdefine: Couldn't define C2");
    retval = -1;
  }
  if (VSfdefine(vdata_id_sepica_level2_data_Bartels, "C3", DFNT_FLOAT32, (1) )) {
    print_sepica_level2_data_Bartels_error("init_cr_sepica_level2_data_Bartels -> VSfdefine: Couldn't define C3");
    retval = -1;
  }
  if (VSfdefine(vdata_id_sepica_level2_data_Bartels, "C4", DFNT_FLOAT32, (1) )) {
    print_sepica_level2_data_Bartels_error("init_cr_sepica_level2_data_Bartels -> VSfdefine: Couldn't define C4");
    retval = -1;
  }
  if (VSfdefine(vdata_id_sepica_level2_data_Bartels, "C5", DFNT_FLOAT32, (1) )) {
    print_sepica_level2_data_Bartels_error("init_cr_sepica_level2_data_Bartels -> VSfdefine: Couldn't define C5");
    retval = -1;
  }
  if (VSfdefine(vdata_id_sepica_level2_data_Bartels, "C6", DFNT_FLOAT32, (1) )) {
    print_sepica_level2_data_Bartels_error("init_cr_sepica_level2_data_Bartels -> VSfdefine: Couldn't define C6");
    retval = -1;
  }
  if (VSfdefine(vdata_id_sepica_level2_data_Bartels, "OlowE", DFNT_FLOAT32, (1) )) {
    print_sepica_level2_data_Bartels_error("init_cr_sepica_level2_data_Bartels -> VSfdefine: Couldn't define OlowE");
    retval = -1;
  }
  if (VSfdefine(vdata_id_sepica_level2_data_Bartels, "O1", DFNT_FLOAT32, (1) )) {
    print_sepica_level2_data_Bartels_error("init_cr_sepica_level2_data_Bartels -> VSfdefine: Couldn't define O1");
    retval = -1;
  }
  if (VSfdefine(vdata_id_sepica_level2_data_Bartels, "O2", DFNT_FLOAT32, (1) )) {
    print_sepica_level2_data_Bartels_error("init_cr_sepica_level2_data_Bartels -> VSfdefine: Couldn't define O2");
    retval = -1;
  }
  if (VSfdefine(vdata_id_sepica_level2_data_Bartels, "O3", DFNT_FLOAT32, (1) )) {
    print_sepica_level2_data_Bartels_error("init_cr_sepica_level2_data_Bartels -> VSfdefine: Couldn't define O3");
    retval = -1;
  }
  if (VSfdefine(vdata_id_sepica_level2_data_Bartels, "O4", DFNT_FLOAT32, (1) )) {
    print_sepica_level2_data_Bartels_error("init_cr_sepica_level2_data_Bartels -> VSfdefine: Couldn't define O4");
    retval = -1;
  }
  if (VSfdefine(vdata_id_sepica_level2_data_Bartels, "O5", DFNT_FLOAT32, (1) )) {
    print_sepica_level2_data_Bartels_error("init_cr_sepica_level2_data_Bartels -> VSfdefine: Couldn't define O5");
    retval = -1;
  }
  if (VSfdefine(vdata_id_sepica_level2_data_Bartels, "Ne1", DFNT_FLOAT32, (1) )) {
    print_sepica_level2_data_Bartels_error("init_cr_sepica_level2_data_Bartels -> VSfdefine: Couldn't define Ne1");
    retval = -1;
  }
  if (VSfdefine(vdata_id_sepica_level2_data_Bartels, "Ne2", DFNT_FLOAT32, (1) )) {
    print_sepica_level2_data_Bartels_error("init_cr_sepica_level2_data_Bartels -> VSfdefine: Couldn't define Ne2");
    retval = -1;
  }
  if (VSfdefine(vdata_id_sepica_level2_data_Bartels, "Ne3", DFNT_FLOAT32, (1) )) {
    print_sepica_level2_data_Bartels_error("init_cr_sepica_level2_data_Bartels -> VSfdefine: Couldn't define Ne3");
    retval = -1;
  }
  if (VSfdefine(vdata_id_sepica_level2_data_Bartels, "Ne4", DFNT_FLOAT32, (1) )) {
    print_sepica_level2_data_Bartels_error("init_cr_sepica_level2_data_Bartels -> VSfdefine: Couldn't define Ne4");
    retval = -1;
  }
  if (VSfdefine(vdata_id_sepica_level2_data_Bartels, "Mg1", DFNT_FLOAT32, (1) )) {
    print_sepica_level2_data_Bartels_error("init_cr_sepica_level2_data_Bartels -> VSfdefine: Couldn't define Mg1");
    retval = -1;
  }
  if (VSfdefine(vdata_id_sepica_level2_data_Bartels, "Mg2", DFNT_FLOAT32, (1) )) {
    print_sepica_level2_data_Bartels_error("init_cr_sepica_level2_data_Bartels -> VSfdefine: Couldn't define Mg2");
    retval = -1;
  }
  if (VSfdefine(vdata_id_sepica_level2_data_Bartels, "Mg3", DFNT_FLOAT32, (1) )) {
    print_sepica_level2_data_Bartels_error("init_cr_sepica_level2_data_Bartels -> VSfdefine: Couldn't define Mg3");
    retval = -1;
  }
  if (VSfdefine(vdata_id_sepica_level2_data_Bartels, "Mg4", DFNT_FLOAT32, (1) )) {
    print_sepica_level2_data_Bartels_error("init_cr_sepica_level2_data_Bartels -> VSfdefine: Couldn't define Mg4");
    retval = -1;
  }
  if (VSfdefine(vdata_id_sepica_level2_data_Bartels, "Si1", DFNT_FLOAT32, (1) )) {
    print_sepica_level2_data_Bartels_error("init_cr_sepica_level2_data_Bartels -> VSfdefine: Couldn't define Si1");
    retval = -1;
  }
  if (VSfdefine(vdata_id_sepica_level2_data_Bartels, "Si2", DFNT_FLOAT32, (1) )) {
    print_sepica_level2_data_Bartels_error("init_cr_sepica_level2_data_Bartels -> VSfdefine: Couldn't define Si2");
    retval = -1;
  }
  if (VSfdefine(vdata_id_sepica_level2_data_Bartels, "Si3", DFNT_FLOAT32, (1) )) {
    print_sepica_level2_data_Bartels_error("init_cr_sepica_level2_data_Bartels -> VSfdefine: Couldn't define Si3");
    retval = -1;
  }
  if (VSfdefine(vdata_id_sepica_level2_data_Bartels, "Si4", DFNT_FLOAT32, (1) )) {
    print_sepica_level2_data_Bartels_error("init_cr_sepica_level2_data_Bartels -> VSfdefine: Couldn't define Si4");
    retval = -1;
  }
  if (VSfdefine(vdata_id_sepica_level2_data_Bartels, "FeloE", DFNT_FLOAT32, (1) )) {
    print_sepica_level2_data_Bartels_error("init_cr_sepica_level2_data_Bartels -> VSfdefine: Couldn't define FeloE");
    retval = -1;
  }
  if (VSfdefine(vdata_id_sepica_level2_data_Bartels, "Fe1", DFNT_FLOAT32, (1) )) {
    print_sepica_level2_data_Bartels_error("init_cr_sepica_level2_data_Bartels -> VSfdefine: Couldn't define Fe1");
    retval = -1;
  }
  if (VSfdefine(vdata_id_sepica_level2_data_Bartels, "Fe2", DFNT_FLOAT32, (1) )) {
    print_sepica_level2_data_Bartels_error("init_cr_sepica_level2_data_Bartels -> VSfdefine: Couldn't define Fe2");
    retval = -1;
  }
  if (VSfdefine(vdata_id_sepica_level2_data_Bartels, "Fe3", DFNT_FLOAT32, (1) )) {
    print_sepica_level2_data_Bartels_error("init_cr_sepica_level2_data_Bartels -> VSfdefine: Couldn't define Fe3");
    retval = -1;
  }
  if (VSfdefine(vdata_id_sepica_level2_data_Bartels, "Fe4", DFNT_FLOAT32, (1) )) {
    print_sepica_level2_data_Bartels_error("init_cr_sepica_level2_data_Bartels -> VSfdefine: Couldn't define Fe4");
    retval = -1;
  }
  if (VSfdefine(vdata_id_sepica_level2_data_Bartels, "unc_H1", DFNT_FLOAT32, (1) )) {
    print_sepica_level2_data_Bartels_error("init_cr_sepica_level2_data_Bartels -> VSfdefine: Couldn't define unc_H1");
    retval = -1;
  }
  if (VSfdefine(vdata_id_sepica_level2_data_Bartels, "unc_H2", DFNT_FLOAT32, (1) )) {
    print_sepica_level2_data_Bartels_error("init_cr_sepica_level2_data_Bartels -> VSfdefine: Couldn't define unc_H2");
    retval = -1;
  }
  if (VSfdefine(vdata_id_sepica_level2_data_Bartels, "unc_H3", DFNT_FLOAT32, (1) )) {
    print_sepica_level2_data_Bartels_error("init_cr_sepica_level2_data_Bartels -> VSfdefine: Couldn't define unc_H3");
    retval = -1;
  }
  if (VSfdefine(vdata_id_sepica_level2_data_Bartels, "unc_He1", DFNT_FLOAT32, (1) )) {
    print_sepica_level2_data_Bartels_error("init_cr_sepica_level2_data_Bartels -> VSfdefine: Couldn't define unc_He1");
    retval = -1;
  }
  if (VSfdefine(vdata_id_sepica_level2_data_Bartels, "unc_He2", DFNT_FLOAT32, (1) )) {
    print_sepica_level2_data_Bartels_error("init_cr_sepica_level2_data_Bartels -> VSfdefine: Couldn't define unc_He2");
    retval = -1;
  }
  if (VSfdefine(vdata_id_sepica_level2_data_Bartels, "unc_He3", DFNT_FLOAT32, (1) )) {
    print_sepica_level2_data_Bartels_error("init_cr_sepica_level2_data_Bartels -> VSfdefine: Couldn't define unc_He3");
    retval = -1;
  }
  if (VSfdefine(vdata_id_sepica_level2_data_Bartels, "unc_He4cal", DFNT_FLOAT32, (1) )) {
    print_sepica_level2_data_Bartels_error("init_cr_sepica_level2_data_Bartels -> VSfdefine: Couldn't define unc_He4cal");
    retval = -1;
  }
  if (VSfdefine(vdata_id_sepica_level2_data_Bartels, "unc_He5", DFNT_FLOAT32, (1) )) {
    print_sepica_level2_data_Bartels_error("init_cr_sepica_level2_data_Bartels -> VSfdefine: Couldn't define unc_He5");
    retval = -1;
  }
  if (VSfdefine(vdata_id_sepica_level2_data_Bartels, "unc_He6", DFNT_FLOAT32, (1) )) {
    print_sepica_level2_data_Bartels_error("init_cr_sepica_level2_data_Bartels -> VSfdefine: Couldn't define unc_He6");
    retval = -1;
  }
  if (VSfdefine(vdata_id_sepica_level2_data_Bartels, "unc_He7", DFNT_FLOAT32, (1) )) {
    print_sepica_level2_data_Bartels_error("init_cr_sepica_level2_data_Bartels -> VSfdefine: Couldn't define unc_He7");
    retval = -1;
  }
  if (VSfdefine(vdata_id_sepica_level2_data_Bartels, "unc_He8", DFNT_FLOAT32, (1) )) {
    print_sepica_level2_data_Bartels_error("init_cr_sepica_level2_data_Bartels -> VSfdefine: Couldn't define unc_He8");
    retval = -1;
  }
  if (VSfdefine(vdata_id_sepica_level2_data_Bartels, "unc_HeCAck", DFNT_FLOAT32, (1) )) {
    print_sepica_level2_data_Bartels_error("init_cr_sepica_level2_data_Bartels -> VSfdefine: Couldn't define unc_HeCAck");
    retval = -1;
  }
  if (VSfdefine(vdata_id_sepica_level2_data_Bartels, "unc_ClowE", DFNT_FLOAT32, (1) )) {
    print_sepica_level2_data_Bartels_error("init_cr_sepica_level2_data_Bartels -> VSfdefine: Couldn't define unc_ClowE");
    retval = -1;
  }
  if (VSfdefine(vdata_id_sepica_level2_data_Bartels, "unc_C1", DFNT_FLOAT32, (1) )) {
    print_sepica_level2_data_Bartels_error("init_cr_sepica_level2_data_Bartels -> VSfdefine: Couldn't define unc_C1");
    retval = -1;
  }
  if (VSfdefine(vdata_id_sepica_level2_data_Bartels, "unc_C2", DFNT_FLOAT32, (1) )) {
    print_sepica_level2_data_Bartels_error("init_cr_sepica_level2_data_Bartels -> VSfdefine: Couldn't define unc_C2");
    retval = -1;
  }
  if (VSfdefine(vdata_id_sepica_level2_data_Bartels, "unc_C3", DFNT_FLOAT32, (1) )) {
    print_sepica_level2_data_Bartels_error("init_cr_sepica_level2_data_Bartels -> VSfdefine: Couldn't define unc_C3");
    retval = -1;
  }
  if (VSfdefine(vdata_id_sepica_level2_data_Bartels, "unc_C4", DFNT_FLOAT32, (1) )) {
    print_sepica_level2_data_Bartels_error("init_cr_sepica_level2_data_Bartels -> VSfdefine: Couldn't define unc_C4");
    retval = -1;
  }
  if (VSfdefine(vdata_id_sepica_level2_data_Bartels, "unc_C5", DFNT_FLOAT32, (1) )) {
    print_sepica_level2_data_Bartels_error("init_cr_sepica_level2_data_Bartels -> VSfdefine: Couldn't define unc_C5");
    retval = -1;
  }
  if (VSfdefine(vdata_id_sepica_level2_data_Bartels, "unc_C6", DFNT_FLOAT32, (1) )) {
    print_sepica_level2_data_Bartels_error("init_cr_sepica_level2_data_Bartels -> VSfdefine: Couldn't define unc_C6");
    retval = -1;
  }
  if (VSfdefine(vdata_id_sepica_level2_data_Bartels, "unc_OlowE", DFNT_FLOAT32, (1) )) {
    print_sepica_level2_data_Bartels_error("init_cr_sepica_level2_data_Bartels -> VSfdefine: Couldn't define unc_OlowE");
    retval = -1;
  }
  if (VSfdefine(vdata_id_sepica_level2_data_Bartels, "unc_O1", DFNT_FLOAT32, (1) )) {
    print_sepica_level2_data_Bartels_error("init_cr_sepica_level2_data_Bartels -> VSfdefine: Couldn't define unc_O1");
    retval = -1;
  }
  if (VSfdefine(vdata_id_sepica_level2_data_Bartels, "unc_O2", DFNT_FLOAT32, (1) )) {
    print_sepica_level2_data_Bartels_error("init_cr_sepica_level2_data_Bartels -> VSfdefine: Couldn't define unc_O2");
    retval = -1;
  }
  if (VSfdefine(vdata_id_sepica_level2_data_Bartels, "unc_O3", DFNT_FLOAT32, (1) )) {
    print_sepica_level2_data_Bartels_error("init_cr_sepica_level2_data_Bartels -> VSfdefine: Couldn't define unc_O3");
    retval = -1;
  }
  if (VSfdefine(vdata_id_sepica_level2_data_Bartels, "unc_O4", DFNT_FLOAT32, (1) )) {
    print_sepica_level2_data_Bartels_error("init_cr_sepica_level2_data_Bartels -> VSfdefine: Couldn't define unc_O4");
    retval = -1;
  }
  if (VSfdefine(vdata_id_sepica_level2_data_Bartels, "unc_O5", DFNT_FLOAT32, (1) )) {
    print_sepica_level2_data_Bartels_error("init_cr_sepica_level2_data_Bartels -> VSfdefine: Couldn't define unc_O5");
    retval = -1;
  }
  if (VSfdefine(vdata_id_sepica_level2_data_Bartels, "unc_Ne1", DFNT_FLOAT32, (1) )) {
    print_sepica_level2_data_Bartels_error("init_cr_sepica_level2_data_Bartels -> VSfdefine: Couldn't define unc_Ne1");
    retval = -1;
  }
  if (VSfdefine(vdata_id_sepica_level2_data_Bartels, "unc_Ne2", DFNT_FLOAT32, (1) )) {
    print_sepica_level2_data_Bartels_error("init_cr_sepica_level2_data_Bartels -> VSfdefine: Couldn't define unc_Ne2");
    retval = -1;
  }
  if (VSfdefine(vdata_id_sepica_level2_data_Bartels, "unc_Ne3", DFNT_FLOAT32, (1) )) {
    print_sepica_level2_data_Bartels_error("init_cr_sepica_level2_data_Bartels -> VSfdefine: Couldn't define unc_Ne3");
    retval = -1;
  }
  if (VSfdefine(vdata_id_sepica_level2_data_Bartels, "unc_Ne4", DFNT_FLOAT32, (1) )) {
    print_sepica_level2_data_Bartels_error("init_cr_sepica_level2_data_Bartels -> VSfdefine: Couldn't define unc_Ne4");
    retval = -1;
  }
  if (VSfdefine(vdata_id_sepica_level2_data_Bartels, "unc_Mg1", DFNT_FLOAT32, (1) )) {
    print_sepica_level2_data_Bartels_error("init_cr_sepica_level2_data_Bartels -> VSfdefine: Couldn't define unc_Mg1");
    retval = -1;
  }
  if (VSfdefine(vdata_id_sepica_level2_data_Bartels, "unc_Mg2", DFNT_FLOAT32, (1) )) {
    print_sepica_level2_data_Bartels_error("init_cr_sepica_level2_data_Bartels -> VSfdefine: Couldn't define unc_Mg2");
    retval = -1;
  }
  if (VSfdefine(vdata_id_sepica_level2_data_Bartels, "unc_Mg3", DFNT_FLOAT32, (1) )) {
    print_sepica_level2_data_Bartels_error("init_cr_sepica_level2_data_Bartels -> VSfdefine: Couldn't define unc_Mg3");
    retval = -1;
  }
  if (VSfdefine(vdata_id_sepica_level2_data_Bartels, "unc_Mg4", DFNT_FLOAT32, (1) )) {
    print_sepica_level2_data_Bartels_error("init_cr_sepica_level2_data_Bartels -> VSfdefine: Couldn't define unc_Mg4");
    retval = -1;
  }
  if (VSfdefine(vdata_id_sepica_level2_data_Bartels, "unc_Si1", DFNT_FLOAT32, (1) )) {
    print_sepica_level2_data_Bartels_error("init_cr_sepica_level2_data_Bartels -> VSfdefine: Couldn't define unc_Si1");
    retval = -1;
  }
  if (VSfdefine(vdata_id_sepica_level2_data_Bartels, "unc_Si2", DFNT_FLOAT32, (1) )) {
    print_sepica_level2_data_Bartels_error("init_cr_sepica_level2_data_Bartels -> VSfdefine: Couldn't define unc_Si2");
    retval = -1;
  }
  if (VSfdefine(vdata_id_sepica_level2_data_Bartels, "unc_Si3", DFNT_FLOAT32, (1) )) {
    print_sepica_level2_data_Bartels_error("init_cr_sepica_level2_data_Bartels -> VSfdefine: Couldn't define unc_Si3");
    retval = -1;
  }
  if (VSfdefine(vdata_id_sepica_level2_data_Bartels, "unc_Si4", DFNT_FLOAT32, (1) )) {
    print_sepica_level2_data_Bartels_error("init_cr_sepica_level2_data_Bartels -> VSfdefine: Couldn't define unc_Si4");
    retval = -1;
  }
  if (VSfdefine(vdata_id_sepica_level2_data_Bartels, "unc_FeloE", DFNT_FLOAT32, (1) )) {
    print_sepica_level2_data_Bartels_error("init_cr_sepica_level2_data_Bartels -> VSfdefine: Couldn't define unc_FeloE");
    retval = -1;
  }
  if (VSfdefine(vdata_id_sepica_level2_data_Bartels, "unc_Fe1", DFNT_FLOAT32, (1) )) {
    print_sepica_level2_data_Bartels_error("init_cr_sepica_level2_data_Bartels -> VSfdefine: Couldn't define unc_Fe1");
    retval = -1;
  }
  if (VSfdefine(vdata_id_sepica_level2_data_Bartels, "unc_Fe2", DFNT_FLOAT32, (1) )) {
    print_sepica_level2_data_Bartels_error("init_cr_sepica_level2_data_Bartels -> VSfdefine: Couldn't define unc_Fe2");
    retval = -1;
  }
  if (VSfdefine(vdata_id_sepica_level2_data_Bartels, "unc_Fe3", DFNT_FLOAT32, (1) )) {
    print_sepica_level2_data_Bartels_error("init_cr_sepica_level2_data_Bartels -> VSfdefine: Couldn't define unc_Fe3");
    retval = -1;
  }
  if (VSfdefine(vdata_id_sepica_level2_data_Bartels, "unc_Fe4", DFNT_FLOAT32, (1) )) {
    print_sepica_level2_data_Bartels_error("init_cr_sepica_level2_data_Bartels -> VSfdefine: Couldn't define unc_Fe4");
    retval = -1;
  }
  if (VSfdefine(vdata_id_sepica_level2_data_Bartels, "up_time_fraction", DFNT_FLOAT32, (1) )) {
    print_sepica_level2_data_Bartels_error("init_cr_sepica_level2_data_Bartels -> VSfdefine: Couldn't define up_time_fraction");
    retval = -1;
  }
  if (VSfdefine(vdata_id_sepica_level2_data_Bartels, "number_of_records_120s", DFNT_INT32, (1) )) {
    print_sepica_level2_data_Bartels_error("init_cr_sepica_level2_data_Bartels -> VSfdefine: Couldn't define number_of_records_120s");
    retval = -1;
  }
  if (VSfdefine(vdata_id_sepica_level2_data_Bartels, "number_of_records_1hr", DFNT_INT32, (1) )) {
    print_sepica_level2_data_Bartels_error("init_cr_sepica_level2_data_Bartels -> VSfdefine: Couldn't define number_of_records_1hr");
    retval = -1;
  }

  if (VSsetfields(vdata_id_sepica_level2_data_Bartels,"year, day, hr, min, sec, fp_year, fp_doy, ACEepoch, H1, H2, H3, He1, He2, He3, He4cal, He5, He6, He7, He8, HeCAck, ClowE, C1, C2, C3, C4, C5, C6, OlowE, O1, O2, O3, O4, O5, Ne1, Ne2, Ne3, Ne4, Mg1, Mg2, Mg3, Mg4, Si1, Si2, Si3, Si4, FeloE, Fe1, Fe2, Fe3, Fe4, unc_H1, unc_H2, unc_H3, unc_He1, unc_He2, unc_He3, unc_He4cal, unc_He5, unc_He6, unc_He7, unc_He8, unc_HeCAck, unc_ClowE, unc_C1, unc_C2, unc_C3, unc_C4, unc_C5, unc_C6, unc_OlowE, unc_O1, unc_O2, unc_O3, unc_O4, unc_O5, unc_Ne1, unc_Ne2, unc_Ne3, unc_Ne4, unc_Mg1, unc_Mg2, unc_Mg3, unc_Mg4, unc_Si1, unc_Si2, unc_Si3, unc_Si4, unc_FeloE, unc_Fe1, unc_Fe2, unc_Fe3, unc_Fe4, up_time_fraction, number_of_records_120s, number_of_records_1hr")){
    print_sepica_level2_data_Bartels_error("init_cr_sepica_level2_data_Bartels -> VSsetfields: Couldn't set fields");
    retval = -1;
  }

  return(retval);
}

/* Included for backwards compatibility */

int32 init_wr_sepica_level2_data_Bartels(int32 hdf_fp, int32 sd_id, int32 an_id, char *classname)
{ return( init_cr_sepica_level2_data_Bartels(hdf_fp, sd_id, an_id, classname) ); }

/******---- write function ----******/

int32 write_sepica_level2_data_Bartels(struct SEPICA_data_Bartels SEPICA_data_Bartels_struc, int32 recnum)
{
  int32 retval = 0;
  uint8 *odata;

void print_sepica_level2_data_Bartels_error();
void pack_sepica_level2_data_Bartels();

  odata = (uint8 *) malloc(sizeof(struct SEPICA_data_Bartels));
  pack_sepica_level2_data_Bartels(odata, &SEPICA_data_Bartels_struc);

  if(recnum!=-1) {
	if(VSseek(vdata_id_sepica_level2_data_Bartels, recnum)==-1) {
		print_sepica_level2_data_Bartels_error("write_sepica_level2_data_Bartels -> VSseek: error.");
		retval = -1;
	}
  }
  if(VSwrite(vdata_id_sepica_level2_data_Bartels, (uint8 *)odata, 1, FULL_INTERLACE) == -1)
    print_sepica_level2_data_Bartels_error("write_sepica_level2_data_Bartels -> VSwrite: Couldn't write data.");

  memset(&SEPICA_data_Bartels_struc, 0, sizeof(struct SEPICA_data_Bartels));
  free(odata);
  return(retval);
}

/*----   close write function    ----*/

void close_wr_sepica_level2_data_Bartels()
{
  VSdetach(vdata_id_sepica_level2_data_Bartels);
  Vdetach(vgrp_id_sepica_level2_data_Bartels);
}

/*----     init access function    ----*/

int32 init_acc_sepica_level2_data_Bartels(int32 hdf_fp, int32 sd_id, char *access_mode)
{
  int32 vdata_ref;
  int32 num_rec;

  void print_sepica_level2_data_Bartels_error();


  if ((vdata_ref = VSfind(hdf_fp, "SEPICA_data_Bartels")) <= 0 ) {
    print_sepica_level2_data_Bartels_error("init_acc_sepica_level2_data_Bartels -> VSfind: Found no vdata of specified type.");
    return(0);
  }
  if ((vdata_id_sepica_level2_data_Bartels = VSattach(hdf_fp, vdata_ref, access_mode)) ==FAIL) {
    print_sepica_level2_data_Bartels_error("init_acc_sepica_level2_data_Bartels -> VSattach: Couldn't attach to hdf file.");
    return(-1);
  }

  VSinquire(vdata_id_sepica_level2_data_Bartels, &num_rec, NULL, NULL, NULL, NULL);
  if (num_rec == 0) { return(0); }


  if (VSsetfields(vdata_id_sepica_level2_data_Bartels,"year, day, hr, min, sec, fp_year, fp_doy, ACEepoch, H1, H2, H3, He1, He2, He3, He4cal, He5, He6, He7, He8, HeCAck, ClowE, C1, C2, C3, C4, C5, C6, OlowE, O1, O2, O3, O4, O5, Ne1, Ne2, Ne3, Ne4, Mg1, Mg2, Mg3, Mg4, Si1, Si2, Si3, Si4, FeloE, Fe1, Fe2, Fe3, Fe4, unc_H1, unc_H2, unc_H3, unc_He1, unc_He2, unc_He3, unc_He4cal, unc_He5, unc_He6, unc_He7, unc_He8, unc_HeCAck, unc_ClowE, unc_C1, unc_C2, unc_C3, unc_C4, unc_C5, unc_C6, unc_OlowE, unc_O1, unc_O2, unc_O3, unc_O4, unc_O5, unc_Ne1, unc_Ne2, unc_Ne3, unc_Ne4, unc_Mg1, unc_Mg2, unc_Mg3, unc_Mg4, unc_Si1, unc_Si2, unc_Si3, unc_Si4, unc_FeloE, unc_Fe1, unc_Fe2, unc_Fe3, unc_Fe4, up_time_fraction, number_of_records_120s, number_of_records_1hr")) {
      print_sepica_level2_data_Bartels_error("init_acc_sepica_level2_data_Bartels -> VSsetfields: Unable to set fields.");
      return(-1);
  }
  return(num_rec);
}

/* Included for backwards compatability */

int32 init_rd_sepica_level2_data_Bartels(int32 hdf_fp, int32 sd_id, char *access_mode)
{ return ( init_acc_sepica_level2_data_Bartels(hdf_fp, sd_id, access_mode) ); }

/******---- read function ----******/

int32 read_sepica_level2_data_Bartels(struct SEPICA_data_Bartels *SEPICA_data_Bartels_struc, int32 recnum_rd)
{
int32 maxrec;
static int32 last_recnum = -1;
int32 retval = 0;
uint8 *odata;

void print_sepica_level2_data_Bartels_error();
void unpack_sepica_level2_data_Bartels();

  if(recnum_rd==-1) recnum_rd=last_recnum+1;

  odata = (uint8 *) malloc(sizeof(struct SEPICA_data_Bartels));
  VSinquire(vdata_id_sepica_level2_data_Bartels, &maxrec, NULL, NULL, NULL, NULL);
  if (recnum_rd >= maxrec) return(-1);
  if (recnum_rd != last_recnum+1)
      if (VSseek(vdata_id_sepica_level2_data_Bartels, recnum_rd)==FAIL) {
          print_sepica_level2_data_Bartels_error("read_sepica_level2_data_Bartels -> VSseek unsuccessful");
          retval = -1;
    }
  last_recnum = recnum_rd;

  if(VSread(vdata_id_sepica_level2_data_Bartels, (uint8 *)odata, 1, FULL_INTERLACE) ==FAIL) {
    print_sepica_level2_data_Bartels_error("read_sepica_level2_data_Bartels -> VSread: Couldn't read data.");
    retval = -1;
  }
  unpack_sepica_level2_data_Bartels(odata, SEPICA_data_Bartels_struc);
  free(odata);
  return(retval);
}

/*----   close read function    ----*/

void close_rd_sepica_level2_data_Bartels()
{
  VSdetach(vdata_id_sepica_level2_data_Bartels);
}

/*----  Read V group description, function    ----*/
void rd_Vgrp_desc_sepica_level2_data_Bartels(int32 hdf_fp, int32 an_id)
{
  int32 ann_id_r;
  int32 num_ann;
  int32 *ann_list;
  int32 vgrp_ref_r;

void print_sepica_level2_data_Bartels_error();

  /*      Get the Vgroup reference     */
  if ((vgrp_ref_r = Vfind(hdf_fp, "VG_SEPICA_data_Bartels" )) ==FAIL)
    print_sepica_level2_data_Bartels_error("rd_Vgrp_sepica_level2_data_Bartels -> Vfind: Couldn't get Vgrp reference.");

  if ((num_ann = ANnumann(an_id, AN_DATA_DESC, DFTAG_VG, vgrp_ref_r)) ==FAIL)
    print_sepica_level2_data_Bartels_error("rd_Vgrp_sepica_level2_data_Bartels -> ANnumann: Couldn't get number of annotations.");

    ann_list = HDmalloc(num_ann * sizeof(int32));
  if ((num_ann = ANannlist(an_id, AN_DATA_DESC, DFTAG_VG, vgrp_ref_r, ann_list)) ==FAIL)
    print_sepica_level2_data_Bartels_error("rd_Vgrp_sepica_level2_data_Bartels -> ANannlist: Couldn't");

  if ((ann_id_r = ANselect(an_id, (num_ann-1), AN_DATA_DESC)) ==FAIL)
    print_sepica_level2_data_Bartels_error("rd_Vgrp_sepica_level2_data_Bartels -> ANselect: Couldn't");

  if (ANreadann(ann_id_r, Vgrp_descrp_SEPICA_data_Bartels, HDstrlen(Vgrp_descrp_SEPICA_data_Bartels)) ==FAIL)
    print_sepica_level2_data_Bartels_error("rd_Vgrp_sepica_level2_data_Bartels -> ANreadann: Couldn't");

  printf("AN: %s\n", Vgrp_descrp_SEPICA_data_Bartels);
  ANendaccess(ann_id_r);
  ANend(an_id);
}

/*----   error function    ----*/

void print_sepica_level2_data_Bartels_error(int8 *mess)
{
  fprintf(stderr,"\nERROR in  hdf_sepica_level2_data_Bartels.c -> %s\n", mess);
  HEprint(stderr, 0);
}

/*----   pack function    ----*/

void pack_sepica_level2_data_Bartels(uint8 *data, struct SEPICA_data_Bartels *SEPICA_data_Bartels_ptr)
{
int32 ptr=0;

   memcpy(data+ptr, &SEPICA_data_Bartels_ptr->year, ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(data+ptr, &SEPICA_data_Bartels_ptr->day, ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(data+ptr, &SEPICA_data_Bartels_ptr->hr, ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(data+ptr, &SEPICA_data_Bartels_ptr->min, ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(data+ptr, &SEPICA_data_Bartels_ptr->sec, ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(data+ptr, &SEPICA_data_Bartels_ptr->fp_year, ((8)*(1)) );
   ptr+= ((8)*(1));
   memcpy(data+ptr, &SEPICA_data_Bartels_ptr->fp_doy, ((8)*(1)) );
   ptr+= ((8)*(1));
   memcpy(data+ptr, &SEPICA_data_Bartels_ptr->ACEepoch, ((8)*(1)) );
   ptr+= ((8)*(1));
   memcpy(data+ptr, &SEPICA_data_Bartels_ptr->H1, ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(data+ptr, &SEPICA_data_Bartels_ptr->H2, ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(data+ptr, &SEPICA_data_Bartels_ptr->H3, ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(data+ptr, &SEPICA_data_Bartels_ptr->He1, ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(data+ptr, &SEPICA_data_Bartels_ptr->He2, ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(data+ptr, &SEPICA_data_Bartels_ptr->He3, ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(data+ptr, &SEPICA_data_Bartels_ptr->He4cal, ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(data+ptr, &SEPICA_data_Bartels_ptr->He5, ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(data+ptr, &SEPICA_data_Bartels_ptr->He6, ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(data+ptr, &SEPICA_data_Bartels_ptr->He7, ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(data+ptr, &SEPICA_data_Bartels_ptr->He8, ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(data+ptr, &SEPICA_data_Bartels_ptr->HeCAck, ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(data+ptr, &SEPICA_data_Bartels_ptr->ClowE, ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(data+ptr, &SEPICA_data_Bartels_ptr->C1, ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(data+ptr, &SEPICA_data_Bartels_ptr->C2, ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(data+ptr, &SEPICA_data_Bartels_ptr->C3, ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(data+ptr, &SEPICA_data_Bartels_ptr->C4, ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(data+ptr, &SEPICA_data_Bartels_ptr->C5, ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(data+ptr, &SEPICA_data_Bartels_ptr->C6, ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(data+ptr, &SEPICA_data_Bartels_ptr->OlowE, ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(data+ptr, &SEPICA_data_Bartels_ptr->O1, ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(data+ptr, &SEPICA_data_Bartels_ptr->O2, ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(data+ptr, &SEPICA_data_Bartels_ptr->O3, ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(data+ptr, &SEPICA_data_Bartels_ptr->O4, ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(data+ptr, &SEPICA_data_Bartels_ptr->O5, ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(data+ptr, &SEPICA_data_Bartels_ptr->Ne1, ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(data+ptr, &SEPICA_data_Bartels_ptr->Ne2, ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(data+ptr, &SEPICA_data_Bartels_ptr->Ne3, ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(data+ptr, &SEPICA_data_Bartels_ptr->Ne4, ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(data+ptr, &SEPICA_data_Bartels_ptr->Mg1, ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(data+ptr, &SEPICA_data_Bartels_ptr->Mg2, ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(data+ptr, &SEPICA_data_Bartels_ptr->Mg3, ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(data+ptr, &SEPICA_data_Bartels_ptr->Mg4, ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(data+ptr, &SEPICA_data_Bartels_ptr->Si1, ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(data+ptr, &SEPICA_data_Bartels_ptr->Si2, ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(data+ptr, &SEPICA_data_Bartels_ptr->Si3, ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(data+ptr, &SEPICA_data_Bartels_ptr->Si4, ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(data+ptr, &SEPICA_data_Bartels_ptr->FeloE, ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(data+ptr, &SEPICA_data_Bartels_ptr->Fe1, ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(data+ptr, &SEPICA_data_Bartels_ptr->Fe2, ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(data+ptr, &SEPICA_data_Bartels_ptr->Fe3, ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(data+ptr, &SEPICA_data_Bartels_ptr->Fe4, ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(data+ptr, &SEPICA_data_Bartels_ptr->unc_H1, ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(data+ptr, &SEPICA_data_Bartels_ptr->unc_H2, ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(data+ptr, &SEPICA_data_Bartels_ptr->unc_H3, ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(data+ptr, &SEPICA_data_Bartels_ptr->unc_He1, ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(data+ptr, &SEPICA_data_Bartels_ptr->unc_He2, ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(data+ptr, &SEPICA_data_Bartels_ptr->unc_He3, ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(data+ptr, &SEPICA_data_Bartels_ptr->unc_He4cal, ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(data+ptr, &SEPICA_data_Bartels_ptr->unc_He5, ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(data+ptr, &SEPICA_data_Bartels_ptr->unc_He6, ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(data+ptr, &SEPICA_data_Bartels_ptr->unc_He7, ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(data+ptr, &SEPICA_data_Bartels_ptr->unc_He8, ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(data+ptr, &SEPICA_data_Bartels_ptr->unc_HeCAck, ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(data+ptr, &SEPICA_data_Bartels_ptr->unc_ClowE, ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(data+ptr, &SEPICA_data_Bartels_ptr->unc_C1, ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(data+ptr, &SEPICA_data_Bartels_ptr->unc_C2, ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(data+ptr, &SEPICA_data_Bartels_ptr->unc_C3, ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(data+ptr, &SEPICA_data_Bartels_ptr->unc_C4, ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(data+ptr, &SEPICA_data_Bartels_ptr->unc_C5, ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(data+ptr, &SEPICA_data_Bartels_ptr->unc_C6, ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(data+ptr, &SEPICA_data_Bartels_ptr->unc_OlowE, ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(data+ptr, &SEPICA_data_Bartels_ptr->unc_O1, ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(data+ptr, &SEPICA_data_Bartels_ptr->unc_O2, ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(data+ptr, &SEPICA_data_Bartels_ptr->unc_O3, ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(data+ptr, &SEPICA_data_Bartels_ptr->unc_O4, ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(data+ptr, &SEPICA_data_Bartels_ptr->unc_O5, ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(data+ptr, &SEPICA_data_Bartels_ptr->unc_Ne1, ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(data+ptr, &SEPICA_data_Bartels_ptr->unc_Ne2, ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(data+ptr, &SEPICA_data_Bartels_ptr->unc_Ne3, ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(data+ptr, &SEPICA_data_Bartels_ptr->unc_Ne4, ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(data+ptr, &SEPICA_data_Bartels_ptr->unc_Mg1, ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(data+ptr, &SEPICA_data_Bartels_ptr->unc_Mg2, ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(data+ptr, &SEPICA_data_Bartels_ptr->unc_Mg3, ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(data+ptr, &SEPICA_data_Bartels_ptr->unc_Mg4, ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(data+ptr, &SEPICA_data_Bartels_ptr->unc_Si1, ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(data+ptr, &SEPICA_data_Bartels_ptr->unc_Si2, ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(data+ptr, &SEPICA_data_Bartels_ptr->unc_Si3, ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(data+ptr, &SEPICA_data_Bartels_ptr->unc_Si4, ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(data+ptr, &SEPICA_data_Bartels_ptr->unc_FeloE, ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(data+ptr, &SEPICA_data_Bartels_ptr->unc_Fe1, ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(data+ptr, &SEPICA_data_Bartels_ptr->unc_Fe2, ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(data+ptr, &SEPICA_data_Bartels_ptr->unc_Fe3, ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(data+ptr, &SEPICA_data_Bartels_ptr->unc_Fe4, ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(data+ptr, &SEPICA_data_Bartels_ptr->up_time_fraction, ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(data+ptr, &SEPICA_data_Bartels_ptr->number_of_records_120s, ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(data+ptr, &SEPICA_data_Bartels_ptr->number_of_records_1hr, ((4)*(1)) );
   ptr+= ((4)*(1));
}

/*----   unpack function    ----*/

void unpack_sepica_level2_data_Bartels(uint8 *data, struct SEPICA_data_Bartels *SEPICA_data_Bartels_ptr)
{
int32 ptr=0;

   memcpy(&SEPICA_data_Bartels_ptr->year, data+ptr,  ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(&SEPICA_data_Bartels_ptr->day, data+ptr,  ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(&SEPICA_data_Bartels_ptr->hr, data+ptr,  ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(&SEPICA_data_Bartels_ptr->min, data+ptr,  ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(&SEPICA_data_Bartels_ptr->sec, data+ptr,  ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(&SEPICA_data_Bartels_ptr->fp_year, data+ptr,  ((8)*(1)) );
   ptr+= ((8)*(1));
   memcpy(&SEPICA_data_Bartels_ptr->fp_doy, data+ptr,  ((8)*(1)) );
   ptr+= ((8)*(1));
   memcpy(&SEPICA_data_Bartels_ptr->ACEepoch, data+ptr,  ((8)*(1)) );
   ptr+= ((8)*(1));
   memcpy(&SEPICA_data_Bartels_ptr->H1, data+ptr,  ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(&SEPICA_data_Bartels_ptr->H2, data+ptr,  ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(&SEPICA_data_Bartels_ptr->H3, data+ptr,  ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(&SEPICA_data_Bartels_ptr->He1, data+ptr,  ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(&SEPICA_data_Bartels_ptr->He2, data+ptr,  ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(&SEPICA_data_Bartels_ptr->He3, data+ptr,  ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(&SEPICA_data_Bartels_ptr->He4cal, data+ptr,  ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(&SEPICA_data_Bartels_ptr->He5, data+ptr,  ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(&SEPICA_data_Bartels_ptr->He6, data+ptr,  ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(&SEPICA_data_Bartels_ptr->He7, data+ptr,  ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(&SEPICA_data_Bartels_ptr->He8, data+ptr,  ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(&SEPICA_data_Bartels_ptr->HeCAck, data+ptr,  ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(&SEPICA_data_Bartels_ptr->ClowE, data+ptr,  ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(&SEPICA_data_Bartels_ptr->C1, data+ptr,  ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(&SEPICA_data_Bartels_ptr->C2, data+ptr,  ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(&SEPICA_data_Bartels_ptr->C3, data+ptr,  ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(&SEPICA_data_Bartels_ptr->C4, data+ptr,  ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(&SEPICA_data_Bartels_ptr->C5, data+ptr,  ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(&SEPICA_data_Bartels_ptr->C6, data+ptr,  ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(&SEPICA_data_Bartels_ptr->OlowE, data+ptr,  ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(&SEPICA_data_Bartels_ptr->O1, data+ptr,  ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(&SEPICA_data_Bartels_ptr->O2, data+ptr,  ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(&SEPICA_data_Bartels_ptr->O3, data+ptr,  ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(&SEPICA_data_Bartels_ptr->O4, data+ptr,  ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(&SEPICA_data_Bartels_ptr->O5, data+ptr,  ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(&SEPICA_data_Bartels_ptr->Ne1, data+ptr,  ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(&SEPICA_data_Bartels_ptr->Ne2, data+ptr,  ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(&SEPICA_data_Bartels_ptr->Ne3, data+ptr,  ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(&SEPICA_data_Bartels_ptr->Ne4, data+ptr,  ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(&SEPICA_data_Bartels_ptr->Mg1, data+ptr,  ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(&SEPICA_data_Bartels_ptr->Mg2, data+ptr,  ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(&SEPICA_data_Bartels_ptr->Mg3, data+ptr,  ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(&SEPICA_data_Bartels_ptr->Mg4, data+ptr,  ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(&SEPICA_data_Bartels_ptr->Si1, data+ptr,  ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(&SEPICA_data_Bartels_ptr->Si2, data+ptr,  ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(&SEPICA_data_Bartels_ptr->Si3, data+ptr,  ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(&SEPICA_data_Bartels_ptr->Si4, data+ptr,  ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(&SEPICA_data_Bartels_ptr->FeloE, data+ptr,  ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(&SEPICA_data_Bartels_ptr->Fe1, data+ptr,  ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(&SEPICA_data_Bartels_ptr->Fe2, data+ptr,  ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(&SEPICA_data_Bartels_ptr->Fe3, data+ptr,  ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(&SEPICA_data_Bartels_ptr->Fe4, data+ptr,  ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(&SEPICA_data_Bartels_ptr->unc_H1, data+ptr,  ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(&SEPICA_data_Bartels_ptr->unc_H2, data+ptr,  ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(&SEPICA_data_Bartels_ptr->unc_H3, data+ptr,  ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(&SEPICA_data_Bartels_ptr->unc_He1, data+ptr,  ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(&SEPICA_data_Bartels_ptr->unc_He2, data+ptr,  ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(&SEPICA_data_Bartels_ptr->unc_He3, data+ptr,  ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(&SEPICA_data_Bartels_ptr->unc_He4cal, data+ptr,  ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(&SEPICA_data_Bartels_ptr->unc_He5, data+ptr,  ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(&SEPICA_data_Bartels_ptr->unc_He6, data+ptr,  ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(&SEPICA_data_Bartels_ptr->unc_He7, data+ptr,  ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(&SEPICA_data_Bartels_ptr->unc_He8, data+ptr,  ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(&SEPICA_data_Bartels_ptr->unc_HeCAck, data+ptr,  ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(&SEPICA_data_Bartels_ptr->unc_ClowE, data+ptr,  ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(&SEPICA_data_Bartels_ptr->unc_C1, data+ptr,  ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(&SEPICA_data_Bartels_ptr->unc_C2, data+ptr,  ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(&SEPICA_data_Bartels_ptr->unc_C3, data+ptr,  ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(&SEPICA_data_Bartels_ptr->unc_C4, data+ptr,  ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(&SEPICA_data_Bartels_ptr->unc_C5, data+ptr,  ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(&SEPICA_data_Bartels_ptr->unc_C6, data+ptr,  ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(&SEPICA_data_Bartels_ptr->unc_OlowE, data+ptr,  ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(&SEPICA_data_Bartels_ptr->unc_O1, data+ptr,  ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(&SEPICA_data_Bartels_ptr->unc_O2, data+ptr,  ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(&SEPICA_data_Bartels_ptr->unc_O3, data+ptr,  ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(&SEPICA_data_Bartels_ptr->unc_O4, data+ptr,  ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(&SEPICA_data_Bartels_ptr->unc_O5, data+ptr,  ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(&SEPICA_data_Bartels_ptr->unc_Ne1, data+ptr,  ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(&SEPICA_data_Bartels_ptr->unc_Ne2, data+ptr,  ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(&SEPICA_data_Bartels_ptr->unc_Ne3, data+ptr,  ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(&SEPICA_data_Bartels_ptr->unc_Ne4, data+ptr,  ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(&SEPICA_data_Bartels_ptr->unc_Mg1, data+ptr,  ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(&SEPICA_data_Bartels_ptr->unc_Mg2, data+ptr,  ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(&SEPICA_data_Bartels_ptr->unc_Mg3, data+ptr,  ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(&SEPICA_data_Bartels_ptr->unc_Mg4, data+ptr,  ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(&SEPICA_data_Bartels_ptr->unc_Si1, data+ptr,  ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(&SEPICA_data_Bartels_ptr->unc_Si2, data+ptr,  ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(&SEPICA_data_Bartels_ptr->unc_Si3, data+ptr,  ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(&SEPICA_data_Bartels_ptr->unc_Si4, data+ptr,  ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(&SEPICA_data_Bartels_ptr->unc_FeloE, data+ptr,  ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(&SEPICA_data_Bartels_ptr->unc_Fe1, data+ptr,  ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(&SEPICA_data_Bartels_ptr->unc_Fe2, data+ptr,  ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(&SEPICA_data_Bartels_ptr->unc_Fe3, data+ptr,  ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(&SEPICA_data_Bartels_ptr->unc_Fe4, data+ptr,  ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(&SEPICA_data_Bartels_ptr->up_time_fraction, data+ptr,  ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(&SEPICA_data_Bartels_ptr->number_of_records_120s, data+ptr,  ((4)*(1)) );
   ptr+= ((4)*(1));
   memcpy(&SEPICA_data_Bartels_ptr->number_of_records_1hr, data+ptr,  ((4)*(1)) );
   ptr+= ((4)*(1));
}
int32 get_vgrp_id_sepica_level2_data_Bartels() {return(vgrp_id_sepica_level2_data_Bartels);}

/*----   V group description function    ----*/

int32 wr_Vgrp_desc_sepica_level2_data_Bartels(char *wr_strval)
{
  strcpy(wr_strval, "The file 'sepica_level2_data_Bartels.h' is shown below, it was used to create the data in the Vgroup named 'VG_SEPICA_data_Bartels'.\n\n");
  strcat(wr_strval,"/* Id: sepica_level2_data_Bartels.h,v 1.2 2001/07/03 00:05:54 steves Exp $ */\n");
  strcat(wr_strval,"\n");
  strcat(wr_strval,"\n");
  strcat(wr_strval,"#include \"hdfi.h\"\n");
  strcat(wr_strval,"\n");
  strcat(wr_strval,"struct SEPICA_data_Bartels {\n");
  strcat(wr_strval,"\n");
  strcat(wr_strval,"  /* UT time at the start of the periods */\n");
  strcat(wr_strval,"  int32   year;                         /* integer year */\n");
  strcat(wr_strval,"  int32   day;                          /* integer day of year */\n");
  strcat(wr_strval,"  int32   hr;                           /* hour of day */\n");
  strcat(wr_strval,"  int32   min;                          /* min of hour */\n");
  strcat(wr_strval,"  float32 sec;                          /* seconds */\n");
  strcat(wr_strval,"  float64 fp_year;                      /* floating point year */\n");
  strcat(wr_strval,"  float64 fp_doy;                       /* floating point Day of YearDOY */ \n");
  strcat(wr_strval,"  float64 ACEepoch;                     /* UT time in sec since 1/1/96 */\n");
  strcat(wr_strval,"\n");
  strcat(wr_strval,"  float32 H1;\n");
  strcat(wr_strval,"  float32 H2;\n");
  strcat(wr_strval,"  float32 H3;\n");
  strcat(wr_strval,"\n");
  strcat(wr_strval,"  float32 He1;\n");
  strcat(wr_strval,"  float32 He2;\n");
  strcat(wr_strval,"  float32 He3;\n");
  strcat(wr_strval,"  float32 He4cal;		/* used in data version 3+ */\n");
  strcat(wr_strval,"  float32 He5;\n");
  strcat(wr_strval,"  float32 He6;\n");
  strcat(wr_strval,"  float32 He7;			/* used in data version 3+ */\n");
  strcat(wr_strval,"  float32 He8;			/* used in data version 3+ */\n");
  strcat(wr_strval,"  float32 HeCAck;		/* used in data version 4+ */\n");
  strcat(wr_strval,"\n");
  strcat(wr_strval,"  float32 ClowE;		/* used in data version 4+ */\n");
  strcat(wr_strval,"  float32 C1;\n");
  strcat(wr_strval,"  float32 C2;\n");
  strcat(wr_strval,"  float32 C3;\n");
  strcat(wr_strval,"  float32 C4;			/* used in data version 3+ */\n");
  strcat(wr_strval,"  float32 C5;			/* used in data version 3+ */\n");
  strcat(wr_strval,"  float32 C6;			/* used in data version 3+ */\n");
  strcat(wr_strval,"\n");
  strcat(wr_strval,"  float32 OlowE;		/* used in data version 4+ */\n");
  strcat(wr_strval,"  float32 O1;\n");
  strcat(wr_strval,"  float32 O2;\n");
  strcat(wr_strval,"  float32 O3;\n");
  strcat(wr_strval,"  float32 O4;\n");
  strcat(wr_strval,"  float32 O5;			/* used in data version 3+ */\n");
  strcat(wr_strval,"\n");
  strcat(wr_strval,"  float32 Ne1;			/* used in data version 3+ */\n");
  strcat(wr_strval,"  float32 Ne2;			/* used in data version 3+ */\n");
  strcat(wr_strval,"  float32 Ne3;			/* used in data version 3+ */\n");
  strcat(wr_strval,"  float32 Ne4;			/* used in data version 3+ */\n");
  strcat(wr_strval,"\n");
  strcat(wr_strval,"  float32 Mg1;			/* used in data version 3+ */\n");
  strcat(wr_strval,"  float32 Mg2;			/* used in data version 3+ */\n");
  strcat(wr_strval,"  float32 Mg3;			/* used in data version 3+ */\n");
  strcat(wr_strval,"  float32 Mg4;			/* used in data version 3+ */\n");
  strcat(wr_strval,"\n");
  strcat(wr_strval,"  float32 Si1;			/* used in data version 3+ */\n");
  strcat(wr_strval,"  float32 Si2;			/* used in data version 3+ */\n");
  strcat(wr_strval,"  float32 Si3;			/* used in data version 3+ */\n");
  strcat(wr_strval,"  float32 Si4;			/* used in data version 3+ */\n");
  strcat(wr_strval,"\n");
  strcat(wr_strval,"  float32 FeloE;		/* used in data version 4+ */\n");
  strcat(wr_strval,"  float32 Fe1;\n");
  strcat(wr_strval,"  float32 Fe2;\n");
  strcat(wr_strval,"  float32 Fe3;\n");
  strcat(wr_strval,"  float32 Fe4;\n");
  strcat(wr_strval,"\n");
  strcat(wr_strval,"  float32 unc_H1;\n");
  strcat(wr_strval,"  float32 unc_H2;\n");
  strcat(wr_strval,"  float32 unc_H3;\n");
  strcat(wr_strval,"\n");
  strcat(wr_strval,"  float32 unc_He1;\n");
  strcat(wr_strval,"  float32 unc_He2;\n");
  strcat(wr_strval,"  float32 unc_He3;\n");
  strcat(wr_strval,"  float32 unc_He4cal;		/* used in data version 3+ */\n");
  strcat(wr_strval,"  float32 unc_He5;\n");
  strcat(wr_strval,"  float32 unc_He6;\n");
  strcat(wr_strval,"  float32 unc_He7;			/* used in data version 3+ */\n");
  strcat(wr_strval,"  float32 unc_He8;			/* used in data version 3+ */\n");
  strcat(wr_strval,"  float32 unc_HeCAck;		/* used in data version 4+ */\n");
  strcat(wr_strval,"\n");
  strcat(wr_strval,"  float32 unc_ClowE;		/* used in data version 4+ */\n");
  strcat(wr_strval,"  float32 unc_C1;\n");
  strcat(wr_strval,"  float32 unc_C2;\n");
  strcat(wr_strval,"  float32 unc_C3;\n");
  strcat(wr_strval,"  float32 unc_C4;			/* used in data version 3+ */\n");
  strcat(wr_strval,"  float32 unc_C5;			/* used in data version 3+ */\n");
  strcat(wr_strval,"  float32 unc_C6;			/* used in data version 3+ */\n");
  strcat(wr_strval,"\n");
  strcat(wr_strval,"  float32 unc_OlowE;		/* used in data version 4+ */\n");
  strcat(wr_strval,"  float32 unc_O1;\n");
  strcat(wr_strval,"  float32 unc_O2;\n");
  strcat(wr_strval,"  float32 unc_O3;\n");
  strcat(wr_strval,"  float32 unc_O4;\n");
  strcat(wr_strval,"  float32 unc_O5;			/* used in data version 3+ */\n");
  strcat(wr_strval,"\n");
  strcat(wr_strval,"  float32 unc_Ne1;			/* used in data version 3+ */\n");
  strcat(wr_strval,"  float32 unc_Ne2;			/* used in data version 3+ */\n");
  strcat(wr_strval,"  float32 unc_Ne3;			/* used in data version 3+ */\n");
  strcat(wr_strval,"  float32 unc_Ne4;			/* used in data version 3+ */\n");
  strcat(wr_strval,"\n");
  strcat(wr_strval,"  float32 unc_Mg1;			/* used in data version 3+ */\n");
  strcat(wr_strval,"  float32 unc_Mg2;			/* used in data version 3+ */\n");
  strcat(wr_strval,"  float32 unc_Mg3;			/* used in data version 3+ */\n");
  strcat(wr_strval,"  float32 unc_Mg4;			/* used in data version 3+ */\n");
  strcat(wr_strval,"\n");
  strcat(wr_strval,"  float32 unc_Si1;			/* used in data version 3+ */\n");
  strcat(wr_strval,"  float32 unc_Si2;			/* used in data version 3+ */\n");
  strcat(wr_strval,"  float32 unc_Si3;			/* used in data version 3+ */\n");
  strcat(wr_strval,"  float32 unc_Si4;			/* used in data version 3+ */\n");
  strcat(wr_strval,"\n");
  strcat(wr_strval,"  float32 unc_FeloE;		/* used in data version 4+ */\n");
  strcat(wr_strval,"  float32 unc_Fe1;\n");
  strcat(wr_strval,"  float32 unc_Fe2;\n");
  strcat(wr_strval,"  float32 unc_Fe3;\n");
  strcat(wr_strval,"  float32 unc_Fe4;\n");
  strcat(wr_strval,"\n");
  strcat(wr_strval,"  float32 up_time_fraction; \n");
  strcat(wr_strval,"  int32   number_of_records_120s;\n");
  strcat(wr_strval,"  int32   number_of_records_1hr;\n");
  strcat(wr_strval,"\n");
  strcat(wr_strval,"};\n");
  return(0);
}
